import { getPool, closePool } from "../config/db.js";
import fs from "fs";
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ==========================================
// 0️⃣ 設定區（不變）
// ==========================================
const CONFIG = {
  ALLOWED_IDS: [
    '1100','1109','1102','1101','1107','1108','110A','110B','110C',
    '110E','110F','110G','110D','110H','110K','110M','1110','1111',
    '1114','1115','1131','1132','113A','113B','113C','113D'
  ],
  TRANSFER: {
    MAX_WAIT_MINUTES: 35,
    BUFFER_MAJOR_STATION: 5,
    BUFFER_MINOR_STATION: 4,
    MAX_CANDIDATE_STATIONS: 8,
    MAX_DETOUR: 5,
  }
};

const TRAIN_ID_MAP = {
  '1101': '太魯閣', '1107': '普悠瑪', '1100': '自強(柴聯/EMU)', '1102': '自強(推拉式)',
  '1108': '自強(推拉式無單車)', '1109': '自強(推拉式)', '110A': '自強(推拉式有單車)',
  '110B': '自強(EMU1200)', '110C': '自強(EMU300)', '110D': '自強(DMU2800)',
  '110E': '自強(DMU2900)', '110F': '自強(DMU3100)', '110G': '新自強(3000)',
  '110H': '新自強(3000)', '110K': '新自強(3000)', '110M': '新自強(3000)',
  '1110': '莒光', '1111': '莒光(身障)', '1114': '莒光(單車)', '1115': '莒光(身障+單車)',
  '1112': '莒光(專開)', '1113': '莒光(郵輪)',
  '1131': '區間車', '1132': '區間快', '113A': '區間(EMU500)', '113B': '區間(EMU700)',
  '113C': '區間(EMU800)', '113D': '區間(EMU900)',
  '1120': '復興號', '1140': '普快車', '1270': '普快(藍皮)'
};

const LOCAL_TRAIN_IDS = new Set(['1131','1132','113A','113B','113C','113D','1140','1270']);

// =====================
// 1️⃣ 基礎建設
// =====================
const graph = JSON.parse(fs.readFileSync(path.join(__dirname, 'adjacency_merged.json'), 'utf8'));

const connection = { execute: (sql, params) => getPool().execute(sql, params) };

const STATION_CACHE_TTL_MS = 60 * 60 * 1000;
let stationCache = { at: 0, data: null };

async function getStationClasses() {
  if (stationCache.data && Date.now() - stationCache.at < STATION_CACHE_TTL_MS) return stationCache.data;
  const sql = `SELECT StationID, StationClass, StationName->>'$.Zh_tw' AS StationName FROM Train.Train_Station`;
  const [rows] = await connection.execute(sql);
  const classes = {};
  rows.forEach(r => classes[r.StationID] = { class: parseInt(r.StationClass), name: r.StationName });
  stationCache = { at: Date.now(), data: classes };
  return classes;
}

// =====================
// 2️⃣ 工具函數（加入跨日處理）
// =====================
function getDayField(day) {
  return ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][day];
}

function timeToMinutes(timeStr) {
  if (!timeStr) return 0;
  const [h, m] = String(timeStr).split(':').map(Number);
  return h * 60 + m;
}

// 跨日核心：模 1440 分鐘
function mod1440(n) { return ((n % 1440) + 1440) % 1440; }

// 從 dep 到 arr 的旅行時間（支援跨午夜）
function calcDuration(depTime, arrTime) {
  return mod1440(timeToMinutes(arrTime) - timeToMinutes(depTime));
}

function formatTime(min) {
  const h = Math.floor(min / 60), m = min % 60;
  return h > 0 ? `${h}小時${m}分` : `${m}分`;
}
function getTrainName(id) { return TRAIN_ID_MAP[id] || `其他(${id})`; }
function getMinBuffer(cls) { return cls <= 1 ? CONFIG.TRANSFER.BUFFER_MAJOR_STATION : CONFIG.TRANSFER.BUFFER_MINOR_STATION; }
function isLocal(id) { return LOCAL_TRAIN_IDS.has(String(id)); }

function getScorePenalty(id1, id2) {
  const isL1 = isLocal(id1);
  const isL2 = isLocal(id2);
  if (isL1 && isL2) return 120;
  if (isL1 || isL2) return 15;
  return 0;
}

// =====================
// 3️⃣ 圖論：Dijkstra + 候選轉乘站（取代單一 BFS）
// =====================
function dijkstraDistances(graph, source) {
  const dist = { [source]: 0 };
  const visited = new Set();
  const pq = [[0, source]];
  while (pq.length) {
    // 小圖用 sort 即可；若規模變大可換 binary heap
    pq.sort((a, b) => a[0] - b[0]);
    const [d, u] = pq.shift();
    if (visited.has(u)) continue;
    visited.add(u);
    const neighbors = graph[u]?.neighbors || [];
    for (const v of neighbors) {
      const nd = d + 1;
      if (dist[v] === undefined || nd < dist[v]) {
        dist[v] = nd;
        pq.push([nd, v]);
      }
    }
  }
  return dist;
}

/**
 * 取得候選轉乘站：
 * - 以「detour = dist(S,s)+dist(s,E)-dist(S,E)」衡量繞行量
 * - 依 (detour, class) 排序後取前 limit 個
 * - 保留原設計「只考慮在圖上有連通關係的站」的語意
 */
function findCandidateTransfers(graph, start, end, stationClasses, options = {}) {
  const limit = options.limit ?? CONFIG.TRANSFER.MAX_CANDIDATE_STATIONS;
  const maxDetour = options.maxDetour ?? CONFIG.TRANSFER.MAX_DETOUR;

  const distFromStart = dijkstraDistances(graph, start);
  const distFromEnd = dijkstraDistances(graph, end);
  const shortest = distFromStart[end];
  if (!Number.isFinite(shortest)) return [];

  const candidates = [];
  for (const id of Object.keys(distFromStart)) {
    if (id === start || id === end) continue;
    if (!(id in distFromEnd)) continue;

    const detour = distFromStart[id] + distFromEnd[id] - shortest;
    if (detour > maxDetour) continue;

    candidates.push({
      id,
      class: stationClasses[id]?.class ?? 99,
      name: stationClasses[id]?.name,
      detour,
      graphDistance: shortest + detour,
    });
  }

  candidates.sort((a, b) => {
    if (a.detour !== b.detour) return a.detour - b.detour;
    return a.class - b.class;
  });

  return candidates.slice(0, limit);
}

// =====================
// 4️⃣ DB：批次查詢 + 車種下推 SQL
// =====================
const LEG_QUERY_PREFIX = `
  SELECT
    t.TrainInfo->>'$.TrainNo'      AS TrainNo,
    t.TrainInfo->>'$.TrainTypeID'  AS TrainTypeID,
    s1.StationID                   AS fromSt,
    s2.StationID                   AS toSt,
    s1.DepartureTime               AS depTime,
    s2.ArrivalTime                 AS arrTime
  FROM Train.GeneralTrainTimetable t
  JOIN JSON_TABLE(t.StopTimes, "$[*]" COLUMNS (
    StopSequence INT PATH "$.StopSequence",
    StationID VARCHAR(10) PATH "$.StationID",
    DepartureTime TIME PATH "$.DepartureTime"
  )) AS s1
  JOIN JSON_TABLE(t.StopTimes, "$[*]" COLUMNS (
    StopSequence INT PATH "$.StopSequence",
    StationID VARCHAR(10) PATH "$.StationID",
    ArrivalTime TIME PATH "$.ArrivalTime"
  )) AS s2
  ON s1.StopSequence < s2.StopSequence
`;

function buildAllowedFilter(allowedIds) {
  if (!allowedIds || allowedIds.length === 0) return { sql: '', params: [] };
  return {
    sql: `AND t.TrainInfo->>'$.TrainTypeID' IN (${allowedIds.map(() => '?').join(',')})`,
    params: allowedIds.map(String),
  };
}

/**
 * 一次查詢「多起點 × 多迄點」的所有可行路段。
 * - startIds、endIds 皆為陣列
 * - 空陣列代表無結果（回傳 []）
 */
async function fetchLegsFromTo(startIds, endIds, day, allowedIds) {
  if (startIds.length === 0 || endIds.length === 0) return [];

  const dayField = getDayField(day);
  if (!dayField) throw new RangeError('day must be 0-6');

  const s1Ph = startIds.map(() => '?').join(',');
  const s2Ph = endIds.map(() => '?').join(',');
  const allowed = buildAllowedFilter(allowedIds);

  const sql = `
    ${LEG_QUERY_PREFIX}
    WHERE s1.StationID IN (${s1Ph})
      AND s2.StationID IN (${s2Ph})
      AND JSON_EXTRACT(t.ServiceDay, '$.${dayField}') = 1
      ${allowed.sql}
    ORDER BY s1.DepartureTime
  `;
  const params = [...startIds, ...endIds, ...allowed.params];
  const [rows] = await connection.execute(sql, params);
  return rows;
}

// =====================
// 5️⃣ 核心查詢
// =====================
async function findDirectTrain(start, end, day, allowedIds) {
  const rows = await fetchLegsFromTo([start], [end], day, allowedIds);
  return rows.map(t => ({
    ...t,
    // ✅ 跨日修正
    travelTime: calcDuration(t.depTime, t.arrTime),
  }));
}

async function findTransferTrains(start, end, day, stationClasses, directTrains, allowedIds) {
  // ✅ 多樣化候選轉乘站（取代單一 BFS）
  const candidates = findCandidateTransfers(graph, start, end, stationClasses);
  if (candidates.length === 0) return [];

  const candidateIds = candidates.map(c => c.id);

  // ✅ 批次查詢：2 次 SQL 取代 2N 次
  const [fromRows, toRows] = await Promise.all([
    fetchLegsFromTo([start], candidateIds, day, allowedIds),
    fetchLegsFromTo(candidateIds, [end], day, allowedIds),
  ]);

  const fromByStation = new Map();
  for (const r of fromRows) {
    if (!fromByStation.has(r.toSt)) fromByStation.set(r.toSt, []);
    fromByStation.get(r.toSt).push(r);
  }
  const toByStation = new Map();
  for (const r of toRows) {
    if (!toByStation.has(r.fromSt)) toByStation.set(r.fromSt, []);
    toByStation.get(r.fromSt).push(r);
  }

  // 組裝可行轉乘
  const allRoutes = [];
  for (const st of candidates) {
    const legs1 = fromByStation.get(st.id) || [];
    const legs2 = toByStation.get(st.id) || [];
    if (legs1.length === 0 || legs2.length === 0) continue;

    const minBuf = getMinBuffer(st.class);
    const maxWait = CONFIG.TRANSFER.MAX_WAIT_MINUTES;

    for (const l1 of legs1) {
      const l1ArrMin = timeToMinutes(l1.arrTime);
      const l1Duration = calcDuration(l1.depTime, l1.arrTime);

      for (const l2 of legs2) {
        const l2DepMin = timeToMinutes(l2.depTime);
        const l2Duration = calcDuration(l2.depTime, l2.arrTime);

        // ✅ 跨日：等待時間用 mod1440 計算
        const waitMin = mod1440(l2DepMin - l1ArrMin);
        if (waitMin < minBuf || waitMin > maxWait) continue;

        const penalty = getScorePenalty(l1.TrainTypeID, l2.TrainTypeID);
        const totalTime = l1Duration + waitMin + l2Duration;

        allRoutes.push({
          station: st,
          l1, l2,
          waitMin, minBuf, totalTime,
          sortScore: totalTime + penalty,
          isTight: (waitMin - minBuf) < 5,
        });
      }
    }
  }

  // ------------------------------------------
  // Step A: 直達車防呆與掩蔽效應
  // ------------------------------------------
  const directByNo = new Map(directTrains.map(t => [t.TrainNo, t]));
  const directDepMins = directTrains.map(t => timeToMinutes(t.depTime));

  const filteredRoutes = allRoutes.filter(r => {
    const d1 = directByNo.get(r.l1.TrainNo);
    const d2 = directByNo.get(r.l2.TrainNo);

    // 規則 1：兩段都是直達 -> 拔除
    if (d1 && d2) return false;

    // 規則 2：A 直達、B 不直達 -> 比較「從同一起站出發」的旅行時間
    // ✅ 跨日修正：用 calcDuration（純時長比較，與絕對時間比較等價）
    if (d1 && !d2) {
      const directDuration = calcDuration(d1.depTime, d1.arrTime);
      if (r.totalTime >= directDuration) return false;
    }

    // 規則 3：A 不直達、B 直達 -> A 沒有比 B 晚出發就拔除
    if (!d1 && d2) {
      const directDepMin = timeToMinutes(d2.depTime);
      const transferDepMin = timeToMinutes(r.l1.depTime);
      if (transferDepMin <= directDepMin) return false;
    }

    // 規則 4：區間轉區間的掩蔽效應
    const isLocalLocal = isLocal(r.l1.TrainTypeID) && isLocal(r.l2.TrainTypeID);
    if (isLocalLocal) {
      const depMin = timeToMinutes(r.l1.depTime);
      const hasDirectNearby = directDepMins.some(dt => Math.abs(dt - depMin) <= 60);
      if (hasDirectNearby) return false;
    }

    return true;
  });

  // ------------------------------------------
  // Step B: 車次去重
  // ------------------------------------------
  const bestRouteMap = new Map();
  for (const route of filteredRoutes) {
    const comboKey = `${route.l1.TrainNo}-${route.l2.TrainNo}`;
    const existing = bestRouteMap.get(comboKey);
    if (
      !existing ||
      route.sortScore < existing.sortScore ||
      (route.sortScore === existing.sortScore && route.waitMin < existing.waitMin)
    ) {
      bestRouteMap.set(comboKey, route);
    }
  }

  // ------------------------------------------
  // Step C: 時段分流
  // ------------------------------------------
  const timeBuckets = Array.from({ length: 24 }, () => []);
  for (const route of bestRouteMap.values()) {
    const depTimeStr = route.l1.depTime || '00:00';
    const hour = parseInt(depTimeStr.split(':')[0], 10) || 0;
    timeBuckets[hour].push(route);
  }

  const timeDistributedRoutes = [];
  for (const bucket of timeBuckets) {
    if (bucket.length === 0) continue;
    bucket.sort((a, b) => a.sortScore - b.sortScore);
    timeDistributedRoutes.push(...bucket.slice(0, 2));
  }

  return timeDistributedRoutes.sort(
    (a, b) => timeToMinutes(a.l1.depTime) - timeToMinutes(b.l1.depTime)
  );
}

// =====================
// 6️⃣ 入口與後製
// =====================
export async function queryTrain({ start, end, day = 1, allowedIds }) {
  const allowed = allowedIds ?? CONFIG.ALLOWED_IDS;
  const stationClasses = await getStationClasses();

  const directTrains = await findDirectTrain(start, end, day, allowed);
  const transferTrains = await findTransferTrains(start, end, day, stationClasses, directTrains, allowed);

  return buildResultJson(start, end, stationClasses, directTrains, transferTrains, allowed);
}

function buildResultJson(startId, endId, stationClasses, direct, transfer, allowed = CONFIG.ALLOWED_IDS) {
  return {
    meta: {
      from: { id: startId, name: stationClasses[startId]?.name },
      to: { id: endId, name: stationClasses[endId]?.name },
      allowedTrainTypes: allowed.length > 0 ? "Filtered" : "ALL",
    },
    direct: direct.map(t => ({
      TrainNo: t.TrainNo,
      TrainTypeID: t.TrainTypeID,
      TrainTypeName: getTrainName(t.TrainTypeID),
      depTime: t.depTime,
      arrTime: t.arrTime,
      travelTime: t.travelTime,
      travelTimeHuman: formatTime(t.travelTime),
    })),
    transfer: transfer.map(r => ({
      transferStation: { id: r.station.id, name: r.station.name, class: r.station.class },
      leg1: {
        TrainNo: r.l1.TrainNo,
        TrainTypeID: r.l1.TrainTypeID,
        TrainTypeName: getTrainName(r.l1.TrainTypeID),
        depTime: r.l1.depTime,
        arrTime: r.l1.arrTime,
      },
      leg2: {
        TrainNo: r.l2.TrainNo,
        TrainTypeID: r.l2.TrainTypeID,
        TrainTypeName: getTrainName(r.l2.TrainTypeID),
        depTime: r.l2.depTime,
        arrTime: r.l2.arrTime,
      },
      waitMin: r.waitMin,
      totalTimeMin: r.totalTime,
      totalTimeHuman: formatTime(r.totalTime),
      isTight: r.isTight,
    })),
  };
}

// ✅ CLI day=0 修正
function parseDayArg(arg, fallback = 1) {
  if (arg === undefined || arg === null || String(arg).trim() === '') return fallback;
  const n = Number(arg);
  if (!Number.isInteger(n) || n < 0 || n > 6) return fallback;
  return n;
}

async function main() {
  const start = process.argv[2] || "3300";
  const end = process.argv[3] || "1194";
  const day = parseDayArg(process.argv[4]);
  const result = await queryTrain({ start, end, day });
  console.log(JSON.stringify(result, null, 2));
  await closePool();
}

if (process.argv[1] === new URL(import.meta.url).pathname) {
  main().catch(console.error);
}

// 對外 API 保持不變，另外 export 內部函式方便測試
export {
  CONFIG, TRAIN_ID_MAP, getTrainName, findDirectTrain, findTransferTrains,
  buildResultJson, fetchLegsFromTo, findCandidateTransfers,
  dijkstraDistances, calcDuration, mod1440, parseDayArg,
};
export default queryTrain;