import mysql from 'mysql2/promise';
import { config } from './env.js';

let pool;
let updatePool;

// 一般資料庫連線
export function getPool() {
    if (!pool) {
        const { host, port, user, password, database } = config.db;

        if (!host || !user || !password) {
            throw new Error(
                'Database environment variables are not set'
            );
        }

        pool = mysql.createPool({
            host,
            port,
            user,
            password,
            database,
            waitForConnections: true,
            connectionLimit: 15,
            queueLimit: 100,
            connectTimeout: 10000,
            enableKeepAlive: true,
            keepAliveInitialDelay: 10000,
        });
    }

    return pool;
}

// 專用資料更新連線
export function getUpdatePool(_db) {
    if (!updatePool) {
        const {
            host,
            port,
            database,
            updateUser,
            updatePassword,
        } = config.db;

        if (!host || !updateUser || !updatePassword) {
            throw new Error(
                'DB_UPDATE_USER / DB_UPDATE_PASSWORD 未設定'
            );
        }

        updatePool = mysql.createPool({
            host,
            port,
            user: updateUser,
            password: updatePassword,
            _db,
            waitForConnections: true,
            connectionLimit: 5,
            queueLimit: 100,
            connectTimeout: 10000,
            enableKeepAlive: true,
            keepAliveInitialDelay: 10000,
        });
    }

    return updatePool;
}

// 關閉所有連線池
export async function closePool() {
    if (pool) {
        await pool.end();
        pool = undefined;
    }

    if (updatePool) {
        await updatePool.end();
        updatePool = undefined;
    }
}