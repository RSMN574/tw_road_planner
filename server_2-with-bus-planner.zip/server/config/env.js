import 'dotenv/config';
import path from 'path';
import { fileURLToPath } from 'url';

export const ROOT_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const required = (name) => {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required environment variable: ${name}`);
  return v;
};

export const config = {
  port: Number(process.env.PORT) || 80,
  tokenFile: process.env.TOKEN_FILE || '/home/rsmn/server/token.txt',
  // CLIENT_ID:process.env.CLIENT_ID ,
  // CLIENT_SECRET:process.env.CLIENT_SECRET ,
  // 缺少時 /tokens 會回 503，而不是接受預設金鑰
  apiKey: process.env.API_KEY || '',
  db: {
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'Train',
    updateUser: process.env.DB_UPDATE_USER,
    updatePassword: process.env.DB_UPDATE_PASSWORD,
  },
  tdx: {
    authUrl:
      'https://tdx.transportdata.tw/auth/realms/TDXConnect/protocol/openid-connect/token',
    timeoutMs: Number(process.env.TDX_TIMEOUT_MS) || 15000,
  },
  required,
};