import fs from 'fs/promises';
import path from 'path';
import { ROOT_DIR } from '../config/env.js';

const cache = new Map();

export async function loadJson(...segments) {
  const file = path.join(ROOT_DIR, 'data', ...segments);
  if (!cache.has(file)) cache.set(file, JSON.parse(await fs.readFile(file, 'utf8')));
  return cache.get(file);
}