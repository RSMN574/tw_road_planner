// /home/rsmn/server/services/metroNormalizer.js
// 將原始 Metro SQL 六張表正規化為 App 可用的資料快照。
// 純函式、無 I/O，可獨立測試。所有推導規則都會寫進 warnings / source 欄位，不憑空補資料。
import { createHash } from 'node:crypto';

// ---- 呈現用設定（不是 SQL 資料，僅供顯示；沒有設定的系統回傳 null，由 App 端處理）----
export const OPERATOR_META = {
  TRTC: { zh: '臺北捷運', en: 'Taipei Metro' },
  NTMCC: { zh: '新北捷運', en: 'New Taipei Metro' },
  NTDLRT: { zh: '淡海輕軌', en: 'Danhai LRT' },
  NTALRT: { zh: '安坑輕軌', en: 'Ankeng LRT' },
  TYMC: { zh: '桃園捷運', en: 'Taoyuan Metro' },
  TMRT: { zh: '臺中捷運', en: 'Taichung Metro' },
  KRTC: { zh: '高雄捷運', en: 'Kaohsiung MRT' },
  KLRT: { zh: '高雄輕軌', en: 'Kaohsiung LRT' },
  MG: { zh: '貓空纜車', en: 'Maokong Gondola' },
};
// 色碼沿用既有 App 寫死資料中已有的線色；其餘為 null（不捏造）。
export const LINE_COLORS = {
  'TRTC-R': 'E50012', 'TRTC-BL': '0070BD', 'TRTC-G': '008659',
  'TRTC-O': 'F8B61C', 'TRTC-BR': 'C48C31',
  'KRTC-R': 'E2001A', 'KRTC-O': 'F39800', 'TMRT-G': '46B131',
};
// 轉乘表中的營運商代碼與車站表不一致時的別名（SQL 內 A3 指向 'NTMC'，車站表為 'NTMCC'）。
const OPERATOR_ALIAS = { NTMC: 'NTMCC' };
const SAME_SYSTEM_MAX_M = 250;

const J = (v) => (v == null || v === '' ? null : typeof v === 'string' ? JSON.parse(v) : v);
const normName = (s) => String(s ?? '').replace(/臺/g, '台').replace(/站$/, '').replace(/\s+/g, '');
const nm = (o) => ({ zh: o?.Zh_tw ?? null, en: o?.En ?? null });

function haversineM(a, b) {
  const R = 6371000, rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLon = rad(b.lon - a.lon);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

// WKT：座標順序為「經度 緯度」(x y)。MULTILINESTRING 各段不保證相連，逐段保留。
export function parseWkt(wkt) {
  const segs = [];
  for (const m of String(wkt).matchAll(/\(([^()]+)\)/g)) {
    const pts = m[1].split(',').map((p) => {
      const [x, y] = p.trim().split(/\s+/).map(Number);
      return [Math.round(x * 1e5) / 1e5, Math.round(y * 1e5) / 1e5];
    }).filter(([x, y]) => Number.isFinite(x) && Number.isFinite(y));
    if (pts.length >= 2) segs.push(pts);
  }
  return segs;
}

export function buildSnapshot(raw) {
  const warnings = [];
  const warn = (m) => warnings.push(m);

  // ---------- 車站 ----------
  const stations = [];
  const byUid = new Map(), byOpId = new Map(), byId = new Map();
  for (const r of raw.metro_station) {
    const i = r.StationUID.indexOf('-');
    const operator = r.StationUID.slice(0, i);
    const pos = J(r.StationPosition) ?? {};
    const name = J(r.StationName) ?? {};
    const s = {
      uid: r.StationUID, operator, code: r.StationID,
      name: nm(name),
      lat: Number.isFinite(pos.PositionLat) ? pos.PositionLat : null,
      lon: Number.isFinite(pos.PositionLon) ? pos.PositionLon : null,
      address: r.StationAddress || null,
      cityCode: r.LocationCityCode || null,
      lineUids: [],
    };
    if (!r.StationUID.endsWith(r.StationID)) warn(`StationUID 與 StationID 不一致：${r.StationUID} / ${r.StationID}`);
    if (byUid.has(s.uid)) { warn(`StationUID 重複：${s.uid}`); continue; }
    if (s.lat == null || s.lon == null) warn(`缺少座標：${s.uid}`);
    stations.push(s); byUid.set(s.uid, s); byOpId.set(`${operator}|${s.code}`, s);
    if (!byId.has(s.code)) byId.set(s.code, []);
    byId.get(s.code).push(s);
  }
  const operators = [...new Set(stations.map((s) => s.operator))];

  // StationID 在同一營運商內才唯一；以「整條路線的站碼都屬於同一營運商」推導路線所屬營運商。
  const resolveOperator = (ids, label, lineId = null, routeZhName = null) => {
    let c = operators.filter((op) => ids.every((id) => byOpId.has(`${op}|${id}`)));
    // route 的站碼可能同時存在於兩個營運商（如 R-3 短交路）；再用「該營運商確實有這條 LineID」縮小範圍
    if (c.length > 1 && lineId) c = c.filter((op) => lines.has(`${op}-${lineId}`));
    // 仍不唯一時，要求該營運商的這條路線包含 route 的全部站（route 是路線的子集）
    if (c.length > 1 && lineId) {
      c = c.filter((op) => {
        const have = new Set(lines.get(`${op}-${lineId}`).stationUids);
        return ids.every((id) => have.has(byOpId.get(`${op}|${id}`).uid));
      });
    }
    // 站碼仍無法分辨時，用 route 名稱（「起點－終點」）比對兩端站名
    if (c.length > 1 && routeZhName) {
      const ends = routeZhName.split(/[－\-–—~]/).map(normName).filter(Boolean).sort().join('|');
      c = c.filter((op) => {
        const a = byOpId.get(`${op}|${ids[0]}`), b = byOpId.get(`${op}|${ids[ids.length - 1]}`);
        return [normName(a.name.zh), normName(b.name.zh)].sort().join('|') === ends;
      });
    }
    if (c.length === 1) return c[0];
    warn(c.length === 0 ? `無法推導營運商（站碼不在任何營運商）：${label}` : `營運商不唯一（${c.join(',')}）：${label}`);
    return null;
  };

  // ---------- 路線 ----------
  const lines = new Map();
  for (const r of raw.metro_station_of_line) {
    const list = (J(r.Stations) ?? []).slice().sort((a, b) => a.Sequence - b.Sequence);
    const op = resolveOperator(list.map((x) => x.StationID), `line ${r.LineID}`);
    if (!op) continue;
    const uid = `${op}-${r.LineID}`;
    if (lines.has(uid)) { warn(`路線重複：${uid}`); continue; }
    const stationUids = list.map((x) => byOpId.get(`${op}|${x.StationID}`).uid);
    for (const su of stationUids) byUid.get(su).lineUids.push(uid);
    lines.set(uid, {
      uid, operator: op, id: r.LineID, no: r.LineNo ?? null, name: { zh: null, en: null },
      color: LINE_COLORS[uid] ?? null, stationUids, edges: [], hasShape: false,
    });
  }

  // ---------- Shape → 路線（LineID 跨系統重複，改以幾何與該線車站的距離配對）----------
  const shapes = [];
  const pool = raw.metro_shape.map((r) => ({ r, segs: parseWkt(r.Geometry), claimed: false }));
  const avgDist = (line, segs) => {
    const verts = segs.flat();
    let sum = 0, n = 0;
    for (const su of line.stationUids) {
      const s = byUid.get(su); if (s.lat == null) continue;
      let best = Infinity;
      for (const [x, y] of verts) { const d = haversineM(s, { lat: y, lon: x }); if (d < best) best = d; }
      sum += best; n++;
    }
    return n ? sum / n : Infinity;
  };
  for (const line of lines.values()) {
    const cands = pool.filter((p) => !p.claimed && p.r.LineID === line.id);
    if (!cands.length) { warn(`路線無 Shape：${line.uid}`); continue; }
    const scored = cands.map((p) => ({ p, d: avgDist(line, p.segs) })).sort((a, b) => a.d - b.d);
    const best = scored[0];
    if (cands.length > 1 && best.d > 500) { warn(`Shape 配對距離過大(${Math.round(best.d)}m)：${line.uid}`); continue; }
    best.p.claimed = true; line.hasShape = true;
    const ln = J(best.p.r.LineName) ?? {};
    line.name = nm(ln);
    shapes.push({ lineUid: line.uid, segments: best.p.segs, encodedPolyline: best.p.r.EncodedPolyline || null, matchDistanceM: Math.round(best.d) });
  }
  for (const p of pool) if (!p.claimed) warn(`未配對的 Shape：LineID=${p.r.LineID}`);

  // ---------- 相鄰關係（edges）：由 route 連續站位推導，並剔除越站（快車）邊 ----------
  const routeByLine = new Map();
  const routes = [];
  for (const r of raw.metro_station_of_route) {
    const list = (J(r.Stations) ?? []).slice().sort((a, b) => a.Sequence - b.Sequence);
    const op = resolveOperator(list.map((x) => x.StationID), `route ${r.RouteID}`, r.LineID, nm(J(r.RouteName)).zh);
    if (!op) continue;
    const luid = `${op}-${r.LineID}`;
    if (!lines.has(luid)) { warn(`route 對應不到路線：${r.RouteID} → ${luid}`); continue; }
    if (!routeByLine.has(luid)) routeByLine.set(luid, []);
    const routeUids = list.map((x) => byOpId.get(`${op}|${x.StationID}`).uid);
    routeByLine.get(luid).push(routeUids);
    // 完整保留 route：名稱（如「頂埔－南港展覽館」）與方向，App 用來顯示「往 ○○ 方向」
    routes.push({
      id: r.RouteID, lineUid: luid, direction: Number(r.Direction),
      name: nm(J(r.RouteName)), stationUids: routeUids,
    });
  }
  for (const line of lines.values()) {
    const routes = routeByLine.get(line.uid);
    if (!routes) {
      warn(`路線無 route，退回以 StationOfLine 順序建邊（分支線可能不準）：${line.uid}`);
      for (let i = 0; i + 1 < line.stationUids.length; i++) line.edges.push([line.stationUids[i], line.stationUids[i + 1]]);
      continue;
    }
    const key = (a, b) => (a < b ? `${a}|${b}` : `${b}|${a}`);
    const cand = new Map(), skipped = new Set();
    for (const seq of routes) {
      const idx = new Map(seq.map((u, i) => [u, i]));
      for (let i = 0; i + 1 < seq.length; i++) cand.set(key(seq[i], seq[i + 1]), [seq[i], seq[i + 1]]);
      // 若某 route 在 a、b 之間還有停靠站，則 a-b 不是相鄰站
      for (const [k, [a, b]] of cand) {
        if (idx.has(a) && idx.has(b) && Math.abs(idx.get(a) - idx.get(b)) > 1) skipped.add(k);
      }
    }
    for (const [k, e] of cand) if (!skipped.has(k)) line.edges.push(e);
  }

  // ---------- 轉乘 ----------
  const links = new Map();
  const addLink = (a, b, extra) => {
    const k = a < b ? `${a}|${b}` : `${b}|${a}`;
    if (!links.has(k)) links.set(k, { a: a < b ? a : b, b: a < b ? b : a, ...extra, declaredBy: [] });
    return links.get(k);
  };
  // (1) 同系統：同營運商、同名（臺/台、「站」字尾正規化）且距離 ≤ 250m 才視為同一實體站。
  //     這是推導，不是 SQL 明確資料，因此標 source='derived'。
  const group = new Map();
  for (const s of stations) { const k = `${s.operator}|${normName(s.name.zh)}`; if (!group.has(k)) group.set(k, []); group.get(k).push(s); }
  for (const g of group.values()) {
    for (let i = 0; i < g.length; i++) for (let j = i + 1; j < g.length; j++) {
      if (g[i].lat == null || g[j].lat == null) continue;
      const d = haversineM(g[i], g[j]);
      if (d <= SAME_SYSTEM_MAX_M) addLink(g[i].uid, g[j].uid, { kind: 'same_system', source: 'derived', distanceM: Math.round(d) });
      else warn(`同名但距離 ${Math.round(d)}m，不視為轉乘：${g[i].uid} / ${g[j].uid}`);
    }
  }
  // (2) 轉乘表：解析每個站的 Rail 轉乘；目標為捷運營運商且車站存在才建立連結。
  const resolveByIdName = (stationId, zhName, label) => {
    const c = byId.get(stationId) ?? [];
    if (c.length === 1) return c[0];
    if (c.length === 0) { warn(`${label}：找不到 StationID=${stationId}`); return null; }
    const hit = c.filter((s) => normName(s.name.zh) === normName(zhName));
    if (hit.length === 1) return hit[0];
    warn(`${label}：StationID=${stationId} 無法以站名分辨營運商`);
    return null;
  };
  const details = new Map();
  const flat = (blocks) => {
    const out = {};
    for (const b of blocks ?? []) for (const [k, v] of Object.entries(b)) {
      if (!k.endsWith('Transfers') || !Array.isArray(v)) continue;
      const mode = k.replace(/Transfers$/, '').replace(/^./, (c) => c.toLowerCase());
      (out[mode] ??= []).push(...v.map((x) => ({
        operatorCode: x.OperatorCode ?? null, operatorName: nm(x.OperatorName),
        stationId: x.StationID ?? null, stationName: nm(x.StationName),
        floor: x.FloorLevel ?? null, description: x.Description ?? null,
        isOnSite: x.IsOnSiteTransfer == null ? null : Number(x.IsOnSiteTransfer) === 1,
      })));
    }
    return out;
  };
  for (const t of raw.metro_station_transfer) {
    const nameZh = nm(J(t.StationName)).zh;
    const src = resolveByIdName(t.StationID, nameZh, '轉乘表');
    if (!src) continue;
    const access = flat(J(t.Transfers));
    const maps = (J(t.InteriorMapURLs) ?? []).map((m) => ({ url: m.MapURL, name: nm(m.MapName), floor: m.FloorLevel ?? null }));
    details.set(src.uid, { ...(details.get(src.uid) ?? { uid: src.uid }), access: { description: t.TransferDescription || null, interiorMaps: maps, ...access } });
    for (const x of access.rail ?? []) {
      const op = OPERATOR_ALIAS[x.operatorCode] ?? x.operatorCode;
      if (!operators.includes(op)) continue; // THSR / TRA 等非捷運，保留在 detail.access.rail
      if (OPERATOR_ALIAS[x.operatorCode]) warn(`轉乘營運商代碼別名：${x.operatorCode} → ${op}（${src.uid}）`);
      const dst = byOpId.get(`${op}|${x.stationId}`);
      if (!dst) { warn(`轉乘目標不存在：${src.uid} → ${op}|${x.stationId}`); continue; }
      const l = addLink(src.uid, dst.uid, { kind: src.operator === dst.operator ? 'same_system' : 'cross_system', source: 'sql' });
      l.source = 'sql'; l.kind = src.operator === dst.operator ? 'same_system' : 'cross_system';
      l.declaredBy.push(src.uid); l.description = l.description ?? x.description; l.isOnSite = l.isOnSite ?? x.isOnSite; l.floor = l.floor ?? x.floor;
      delete l.distanceM;
    }
  }
  // ---------- 設施 ----------
  const fl = (arr) => (J(arr) ?? []).map((e) => ({ floor: e.FloorLevel ?? null, description: e.Description ?? null }));
  for (const f of raw.metro_station_facility) {
    const s = resolveByIdName(f.StationID, nm(J(f.StationName)).zh, '設施表');
    if (!s) continue;
    const d = details.get(s.uid) ?? { uid: s.uid };
    d.facilities = {
      elevators: fl(f.Elevators), infoSpots: fl(f.InformationSpots),
      drinkingFountains: fl(f.DrinkingFountains), toilets: fl(f.Toilets),
      maps: (J(f.FacilityMapURLs) ?? []).map((m) => ({ url: m.MapURL, name: nm(m.MapName), floor: m.FloorLevel ?? null })),
      updatedAt: f.UpdateTime ?? null,
    };
    details.set(s.uid, d);
  }

  // ---------- 實體站分組 ----------
  // 同一個實體站在 SQL 裡會有多個站碼（如台北車站 R10 與 BL12）。
  // 只以「同系統轉乘連結」（資料明列，或同名且 250m 內推導）合併；跨營運商不合併。
  const parent = new Map(stations.map((x) => [x.uid, x.uid]));
  const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
  for (const l of links.values()) if (l.kind === 'same_system') parent.set(find(l.a), find(l.b));
  const members = new Map();
  for (const x of stations) { const r = find(x.uid); if (!members.has(r)) members.set(r, []); members.get(r).push(x); }
  const groups = [];
  for (const list of members.values()) {
    list.sort((a, b) => (a.uid < b.uid ? -1 : 1));
    const withPos = list.filter((x) => x.lat != null && x.lon != null);
    const id = `g:${list[0].uid}`;
    for (const x of list) x.groupId = id;
    groups.push({
      id, operator: list[0].operator, name: list[0].name,
      lat: withPos.length ? withPos.reduce((a, x) => a + x.lat, 0) / withPos.length : null,
      lon: withPos.length ? withPos.reduce((a, x) => a + x.lon, 0) / withPos.length : null,
      stationUids: list.map((x) => x.uid),
      codes: list.map((x) => x.code),
      lineUids: [...new Set(list.flatMap((x) => x.lineUids))],
    });
  }

  // ---------- 候選轉乘（資料未明列，僅供提示，不參與路徑規劃）----------
  // 跨營運商、距離 ≤300m 且（同名 或 ≤200m）。可能是真的轉乘，但 SQL 沒有明列，所以標 source='proximity'。
  const candidateLinks = [];
  for (let i = 0; i < stations.length; i++) for (let j = i + 1; j < stations.length; j++) {
    const a = stations[i], b = stations[j];
    if (a.operator === b.operator || a.lat == null || b.lat == null) continue;
    const k = a.uid < b.uid ? `${a.uid}|${b.uid}` : `${b.uid}|${a.uid}`;
    if (links.has(k)) continue;
    const d = haversineM(a, b);
    if (d <= 300 && (normName(a.name.zh) === normName(b.name.zh) || d <= 200)) {
      candidateLinks.push({ a: a.uid < b.uid ? a.uid : b.uid, b: a.uid < b.uid ? b.uid : a.uid, kind: 'cross_system', source: 'proximity', distanceM: Math.round(d) });
    }
  }

  // ---------- 系統 ----------
  const systems = operators.map((code) => {
    const st = stations.filter((s) => s.operator === code);
    const ls = [...lines.values()].filter((l) => l.operator === code);
    const meta = OPERATOR_META[code] ?? { zh: code, en: code };
    return {
      code, name: { zh: meta.zh, en: meta.en },
      cityCodes: [...new Set(st.map((s) => s.cityCode).filter(Boolean))],
      lineUids: ls.map((l) => l.uid), stationCount: st.length,
      coverage: {
        shape: ls.length > 0 && ls.every((l) => l.hasShape),
        facilityStations: st.filter((s) => details.get(s.uid)?.facilities).length,
        transferStations: st.filter((s) => details.get(s.uid)?.access).length,
      },
    };
  });

  const stamp = ['metro_station', 'metro_station_of_line', 'metro_station_of_route', 'metro_station_facility', 'metro_station_transfer', 'metro_shape']
    .map((t) => `${t}:${raw[t].length}:${raw[t].map((r) => r.UpdateTime ?? '').sort().pop() ?? ''}`).join(';');
  const version = createHash('sha1').update(stamp).digest('hex').slice(0, 16);

  return {
    version, generatedAt: new Date().toISOString(),
    catalog: { version, systems, lines: [...lines.values()], stations, groups, routes, links: [...links.values()], candidateLinks },
    shapes: { version, shapes },
    details, warnings,
  };
}
