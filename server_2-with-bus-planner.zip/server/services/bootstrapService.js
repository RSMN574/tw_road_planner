// /home/rsmn/server/services/bootstrapService.js
import { query } from '../db.js';

// bus_route 欄位：City, CityCode, TicketPriceDescriptionZh/En 都有
const SHARED_SELECT = `
  SELECT RouteID AS routeId, RouteUID AS routeUid, RouteName,
         City, CityCode,
         HasSubRoutes, Operators, SubRoutes,
         DepartureStopNameZh, DepartureStopNameEn,
         DestinationStopNameZh, DestinationStopNameEn,
         TicketPriceDescriptionZh, TicketPriceDescriptionEn,
         RouteMapImageUrl, UpdateTime, VersionID
  FROM Bus.bus_route
`;

// Bus_InterCity_Route 沒有 CityCode，也沒有 TicketPriceDescriptionZh/En
// 城市以 'InterCity' 常值補上
const INTERCITY_SELECT = `
  SELECT RouteID AS routeId, RouteUID AS routeUid, RouteName,
         'InterCity' AS City,
         HasSubRoutes, Operators, SubRoutes,
         DepartureStopNameZh, DepartureStopNameEn,
         DestinationStopNameZh, DestinationStopNameEn,
         RouteMapImageUrl, UpdateTime, VersionID
  FROM Bus.Bus_InterCity_Route
`;

export async function buildBootstrap(city) {
  const c = (city || '').trim();

  let busList;

  if (!c || c === 'all') {
    // 全部：共用表 + 跨城際
    const shared = await query(SHARED_SELECT);
    const interCity = await query(INTERCITY_SELECT);
    busList = [...shared, ...interCity];
  } else if (c === 'InterCity') {
    busList = await query(INTERCITY_SELECT);
  } else {
    busList = await query(
      `${SHARED_SELECT} WHERE City = ?`,
      [c]
    );
  }

  return {
    version: new Date().toISOString(),
    city: c || 'all',
    busList,
  };
}