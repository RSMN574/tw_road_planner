// /home/rsmn/server/services/metroCatalogService.js
// 讀取 Metro 資料庫的六張原始表 → 正規化 → 記憶體快取。
// 沿用 bootstrapService 的慣例：使用 ../db.js 的 query，並以「資料庫.資料表」限定名稱跨庫查詢。
import { query } from '../db.js';
import { config } from '../config/env.js';
import { buildSnapshot } from './metroNormalizer.js';
import { logger } from '../utils/logger.js';

const TABLES = [
  'metro_station',
  'metro_station_of_line',
  'metro_station_of_route',
  'metro_station_facility',
  'metro_station_transfer',
  'metro_shape',
];
const DB_NAME_RE = /^[A-Za-z0-9_]{1,64}$/;

/**
 * 解析 Metro 資料庫名稱：config.metroDb → 環境變數 METRO_DB_NAME → 'Metro'。
 * 即使 config/env.js 沒有 metroDb 欄位（舊版或漏部署）也會退回預設值，不會變成 undefined。
 */
export function resolveMetroDb() {
  const db = config.metroDb || process.env.METRO_DB_NAME || 'Metro';
  // 必須是字串：RegExp.test(undefined) 會把它轉成 "undefined" 而誤判通過
  if (typeof db !== 'string' || !DB_NAME_RE.test(db)) throw new Error('METRO_DB_NAME 格式錯誤');
  return db;
}

/** 從 MySQL 讀取原始資料。資料庫名稱驗證格式後才組進 SQL。 */
export async function loadRawFromDb() {
  const db = resolveMetroDb();
  const raw = {};
  for (const t of TABLES) {
    raw[t] = await query(`SELECT * FROM \`${db}\`.\`${t}\``);
  }
  return raw;
}

/**
 * 記憶體快取 + 並行請求合併。
 * 重新整理失敗但已有舊資料時沿用舊資料，避免一次 DB 失敗就讓整個功能不可用。
 */
export function createMetroCatalogService({ loadRaw = loadRawFromDb, ttlMs = 10 * 60 * 1000 } = {}) {
  let snapshot = null;
  let loadedAt = 0;
  let inflight = null;

  async function refresh() {
    const next = buildSnapshot(await loadRaw());
    next.stationUids = new Set(next.catalog.stations.map((s) => s.uid));
    next.operatorCodes = new Set(next.catalog.systems.map((s) => s.code));
    for (const w of next.warnings) logger.warn(`[metro-v2] ${w}`);
    snapshot = next;
    loadedAt = Date.now();
    return snapshot;
  }

  async function getSnapshot() {
    const fresh = snapshot && Date.now() - loadedAt < ttlMs;
    if (fresh) return snapshot;
    if (!inflight) {
      inflight = refresh()
        .catch((e) => {
          logger.error('[metro-v2] 載入失敗', e);
          if (!snapshot) throw e;
          return snapshot;
        })
        .finally(() => { inflight = null; });
    }
    return snapshot ? snapshot : inflight; // 有舊資料時不阻塞請求，背景更新
  }

  return { getSnapshot };
}

export const metroCatalogService = createMetroCatalogService();
