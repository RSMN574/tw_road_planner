'use strict';
const { query } = require('../db');
const { STOP_TABLE } = require('./routeService');

// ── 對照 getBusStop（站名 LIKE） ──
async function searchStations(city, input) {
  const c = (city || '').trim();
  const like = `%${input}%`;

  if (c === 'all') {
    return await query(
      `SELECT StationName FROM Bus.Bus_Taichung_Stop
       WHERE JSON_UNQUOTE(JSON_EXTRACT(StationName, '$.Zh_tw')) LIKE ?`,
      [like]
    );
  }
  if (c === 'InterCity') {
    return await query(
      `SELECT StationName FROM Bus.Bus_InterCity_Route_Stop
       WHERE JSON_UNQUOTE(JSON_EXTRACT(StationName, '$.Zh_tw')) LIKE ?`,
      [like]
    );
  }
  const table = STOP_TABLE[c];
  if (!table) return [];
  return await query(
    `SELECT StationName FROM ${table}
     WHERE JSON_UNQUOTE(JSON_EXTRACT(StationName, '$.Zh_tw')) LIKE ?`,
    [like]
  );
}

// ── 對照 GetBusStopInfo ──
async function getStationInfo(city, stopName) {
  const c = (city || '').trim();
  const table = STOP_TABLE[c];
  if (!table) return [];
  return await query(
    `SELECT StationID, StationPosition FROM ${table}
     WHERE JSON_UNQUOTE(JSON_EXTRACT(StationName, '$.Zh_tw')) = ?`,
    [stopName]
  );
}

module.exports = { searchStations, getStationInfo };