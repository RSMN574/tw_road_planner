import fs from 'fs/promises';
import { config } from '../config/env.js';
import { logger } from '../utils/logger.js';


export async function readToken() {
  const tokenFile = config.tokenFile;

  try {
    const token = await fs.readFile(tokenFile, 'utf8');
    const value = token.trim();

    if (!value) {
      throw new Error(`Token file is empty: ${tokenFile}`);
    }

    return value;
  } catch (error) {
    logger.error('Failed to read TDX token', {
      path: tokenFile,
      code: error.code,
      message: error.message,
    });

    throw error;
  }
}

export async function fetchTdxToken() {
  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: config.required('CLIENT_ID'),
    client_secret: config.required('CLIENT_SECRET'),
  });
  const res = await fetch(config.tdx.authUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    signal: AbortSignal.timeout(config.tdx.timeoutMs),
  });
  if (!res.ok) throw new Error(`TDX token request failed: HTTP ${res.status}`);
  const data = await res.json();
  if (!data.access_token) throw new Error('TDX token response has no access_token');
  return data.access_token;
}

// 先寫暫存檔再 rename，避免讀取端讀到不完整的 Token
export async function writeToken(token) {
  const tokenFile = config.tokenFile;
  const tmp = `${tokenFile}.tmp`;

  try {
    // 寫入暫存檔
    await fs.writeFile(tmp, token, { mode: 0o600 });

    // 確保暫存檔權限為 rw-------
    await fs.chmod(tmp, 0o600);

    // 原子替換 Token 檔案
    await fs.rename(tmp, tokenFile);

    // 確保目標檔案權限為 rw-------
    await fs.chmod(tokenFile, 0o600);
  } catch (error) {
    // 發生錯誤時清理暫存檔
    await fs.unlink(tmp).catch(() => {});
    throw error;
  }
}

export async function refreshToken() {
  const token = await fetchTdxToken();
  await writeToken(token);
  logger.info('TDX token refreshed');
}