// services/predict-service.js
// ============================================================
// 台北/台中 YouBike 站點供需預測服務
// - 給 CLI 與 REST API 共用
// - 依「同星期幾 × 同時段 ±window」歷史樣本 + 短期線性趨勢融合
// - 內建快取、離群值過濾、時間加權、自適應窗口（可選）
// ============================================================

import { query } from '../db.js';

// ============================================================
// 常數
// ============================================================
const WEEKDAY_ZH = ['週日', '週一', '週二', '週三', '週四', '週五', '週六'];

const DEFAULTS = {
  days: 30,              // 回看天數
  window: 60,            // 同時段窗口（分鐘）
  minWindow: 5,          // 窗口下限
  maxWindow: 180,        // 窗口上限
  cacheTTLms: 5 * 60_000,// 快取存活時間
  halfLifeDays: 7,       // 時間加權半衰期
  useAdaptiveWindow: false, // 自適應窗口
  useOutlierFilter: true,   // 離群值過濾
  useTimeWeight: true,      // 時間加權
  useTrend: true,           // 短期趨勢
  trendHours: 3,            // 趨勢啟用範圍（目標時間距現在 <= N 小時）
  trendMaxAheadMin: 120,    // 趨勢外推上限（分鐘）
  sampleWeightCap: 8,       // wSample = min(n/cap, 1)
  sigmaMultiplier: 1.5,     // 信心區間 = ±kσ
  sigmaMin: 2,              // σ 下限
};

// ============================================================
// 快取
// ============================================================
const CACHE = new Map();
function cacheKey(station, target, opts) {
  return [
    station,
    target.toISOString(),
    opts.days, opts.window,
    opts.useAdaptiveWindow ? 1 : 0,
    opts.useOutlierFilter ? 1 : 0,
    opts.useTimeWeight ? 1 : 0,
    opts.useTrend ? 1 : 0,
  ].join('|');
}
function cacheGet(key) {
  const hit = CACHE.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > hit.ttl) { CACHE.delete(key); return null; }
  return hit.value;
}
function cacheSet(key, value, ttl) {
  if (CACHE.size > 500) {
    // 清掉最舊的 100 筆
    const sorted = [...CACHE.entries()].sort((a, b) => a[1].at - b[1].at);
    sorted.slice(0, 100).forEach(([k]) => CACHE.delete(k));
  }
  CACHE.set(key, { value, at: Date.now(), ttl });
}

// ============================================================
// 統計工具
// ============================================================
const sum    = a => a.reduce((s, x) => s + x, 0);
const mean   = a => a.length ? sum(a) / a.length : 0;
const median = a => {
  if (!a.length) return 0;
  const s = [...a].sort((x, y) => x - y);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
};
const std = a => {
  if (a.length < 2) return 0;
  const m = mean(a);
  return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1));
};
const toMin = d => d.getHours() * 60 + d.getMinutes();
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// 線性回歸 y = slope*x + intercept
function linreg(pts) {
  const n = pts.length;
  if (n < 2) return { slope: 0, intercept: pts[0]?.y ?? 0 };
  const sx  = sum(pts.map(p => p.x));
  const sy  = sum(pts.map(p => p.y));
  const sxy = sum(pts.map(p => p.x * p.y));
  const sxx = sum(pts.map(p => p.x * p.x));
  const denom = n * sxx - sx * sx;
  if (denom === 0) return { slope: 0, intercept: sy / n };
  const slope = (n * sxy - sx * sy) / denom;
  return { slope, intercept: (sy - slope * sx) / n };
}

// IQR 離群值過濾
function removeOutliers(values) {
  if (values.length < 4) return values;
  const s = [...values].sort((a, b) => a - b);
  const q1 = s[Math.floor((s.length - 1) * 0.25)];
  const q3 = s[Math.floor((s.length - 1) * 0.75)];
  const iqr = q3 - q1;
  if (iqr === 0) return values;
  const lo = q1 - 1.5 * iqr;
  const hi = q3 + 1.5 * iqr;
  return values.filter(v => v >= lo && v <= hi);
}

// 時間加權均值（半衰期 halfLifeDays 天）
function weightedMean(samples, halfLifeDays = 7) {
  const now = Date.now();
  let sw = 0, sv = 0;
  for (const { ts, value } of samples) {
    const ageDays = Math.max(0, (now - ts.getTime()) / 86400_000);
    const w = Math.pow(0.5, ageDays / halfLifeDays);
    sw += w;
    sv += w * value;
  }
  return sw > 0 ? sv / sw : 0;
}

// 自適應窗口（分）
function adaptiveWindow(hour, base) {
  if (hour >= 7 && hour <= 9)   return Math.min(base, 20);   // 早尖峰
  if (hour >= 17 && hour <= 19) return Math.min(base, 20);   // 晚尖峰
  if (hour >= 0 && hour <= 5)   return Math.max(base, 90);   // 深夜
  return base;
}

// ============================================================
// 資料抓取
// ============================================================
export async function fetchHistory(stationUID, lookbackDays) {
  if (!stationUID) throw makeError('MISSING_STATION', '缺少 stationUID');

  const since = new Date(Date.now() - lookbackDays * 86400_000)
    .toISOString().slice(0, 19).replace('T', ' ');

  const sql = `
    SELECT
      CAST(JSON_UNQUOTE(JSON_EXTRACT(raw_data, '$.AvailableRentBikes'))   AS SIGNED) AS rent,
      CAST(JSON_UNQUOTE(JSON_EXTRACT(raw_data, '$.AvailableReturnBikes')) AS SIGNED) AS ret,
      CAST(JSON_UNQUOTE(JSON_EXTRACT(raw_data, '$.AvailableRentBikesDetail.GeneralBikes'))  AS SIGNED) AS gen,
      CAST(JSON_UNQUOTE(JSON_EXTRACT(raw_data, '$.AvailableRentBikesDetail.ElectricBikes')) AS SIGNED) AS elec,
      STR_TO_DATE(
        REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(raw_data, '$.SrcUpdateTime')),'T',' '),'+08:00',''),
        '%Y-%m-%d %H:%i:%s'
      ) AS ts
    FROM Bike.bike_availability_history
    WHERE JSON_UNQUOTE(JSON_EXTRACT(raw_data, '$.StationUID')) = ?
      AND STR_TO_DATE(
        REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(raw_data, '$.SrcUpdateTime')),'T',' '),'+08:00',''),
        '%Y-%m-%d %H:%i:%s'
      ) >= ?
    ORDER BY ts ASC
  `;

  const rows = await query(sql, [stationUID, since]);
  if (!Array.isArray(rows)) {
    throw makeError('QUERY_ERROR', `query 回傳非陣列（實際：${typeof rows}）`);
  }

  return rows
    .filter(r => r.ts && r.rent != null && r.ret != null)
    .map(r => ({
      ts: new Date(r.ts),
      rent: Number(r.rent),
      ret:  Number(r.ret),
      gen:  Number(r.gen  || 0),
      elec: Number(r.elec || 0),
    }));
}

// ============================================================
// 風險評估
// ============================================================
function assessRisk(rent, ret, total, elecRatio) {
  const alerts = [];
  let level = 'low';

  if (rent <= 2) {
    alerts.push('⚠️ 無車風險高');
    level = 'high';
  } else if (rent <= 0.15 * total) {
    alerts.push('⚠️ 可借車偏低');
    level = 'medium';
  }

  if (ret <= 2) {
    alerts.push('⚠️ 滿站風險高');
    level = 'high';
  } else if (ret <= 0.15 * total) {
    alerts.push('⚠️ 可還空位偏低');
    if (level === 'low') level = 'medium';
  }

  if (elecRatio < 0.15 && rent > 0) {
    alerts.push('ℹ️ 電動車比例偏低');
  }

  if (!alerts.length) alerts.push('✅ 供需正常');

  return {
    level,
    rentRatio:   +(rent / total).toFixed(3),
    returnRatio: +(ret  / total).toFixed(3),
    alerts,
  };
}

// ============================================================
// 核心運算（純函式）
// ============================================================
export function computePrediction(rows, target, options = {}) {
  if (!Array.isArray(rows) || !rows.length) {
    throw makeError('NO_DATA', '無歷史資料可運算');
  }
  if (!(target instanceof Date) || isNaN(target.getTime())) {
    throw makeError('INVALID_TIME', '目標時間無效');
  }

  const opts = { ...DEFAULTS, ...options };
  const targetWD  = target.getDay();
  const targetHr  = target.getHours();
  const targetMin = toMin(target);

  // 總車位（取歷史最大值推估）
  const totalSlots = Math.max(...rows.map(r => r.rent + r.ret)) || 26;

  // ---- (1) 決定窗口 ----
  const WINDOW_MIN = opts.useAdaptiveWindow
    ? adaptiveWindow(targetHr, opts.window)
    : opts.window;

  // ---- (2) 篩樣本 ----
  const timeWindowSamples = rows.filter(r => {
    if (r.ts.getDay() !== targetWD) return false;
    const diff = Math.abs(toMin(r.ts) - targetMin);
    return Math.min(diff, 1440 - diff) <= WINDOW_MIN;
  });

  // ---- (3) 短期趨勢 ----
  const now = new Date();
  const lastTs = rows[rows.length - 1].ts;
  const hoursFromNow = (target - now) / 3600_000;
  const useTrend = opts.useTrend
    && hoursFromNow >= 0
    && hoursFromNow <= opts.trendHours;

  let trendRent = null, trendRet = null;
  let trendSlopeRent = 0, trendSlopeRet = 0;
  if (useTrend) {
    const recent = rows.filter(r => lastTs - r.ts <= 60 * 60_000);
    if (recent.length >= 3) {
      const xBase = recent[0].ts.getTime() / 60000;
      const lrR = linreg(recent.map(r => ({ x: r.ts.getTime() / 60000 - xBase, y: r.rent })));
      const lrT = linreg(recent.map(r => ({ x: r.ts.getTime() / 60000 - xBase, y: r.ret })));
      const maxAhead = Math.min(target.getTime() / 60000 - xBase, opts.trendMaxAheadMin);
      trendRent = lrR.intercept + lrR.slope * maxAhead;
      trendRet  = lrT.intercept + lrT.slope * maxAhead;
      trendSlopeRent = lrR.slope;
      trendSlopeRet  = lrT.slope;
    }
  }

  // ---- (4) 樣本統計（可選離群 + 加權）----
  const rawRent = timeWindowSamples.map(r => r.rent);
  const rawRet  = timeWindowSamples.map(r => r.ret);

  const rentVals = opts.useOutlierFilter ? removeOutliers(rawRent) : rawRent;
  const retVals  = opts.useOutlierFilter ? removeOutliers(rawRet)  : rawRet;

  const weightedSamples = (field) => timeWindowSamples.map(r => ({ ts: r.ts, value: r[field] }));
  const getMean = (field, vals) => opts.useTimeWeight && timeWindowSamples.length
    ? weightedMean(weightedSamples(field), opts.halfLifeDays)
    : mean(vals);

  const statRent = {
    mean:   getMean('rent', rentVals),
    median: median(rentVals),
    std:    std(rentVals),
    n:      rentVals.length,
  };
  const statRet = {
    mean:   getMean('ret', retVals),
    median: median(retVals),
    std:    std(retVals),
    n:      retVals.length,
  };

  // ---- (5) 融合 ----
  const wSample = Math.min(statRent.n / opts.sampleWeightCap, 1);
  const wTrend  = 1 - wSample;

  const baselineRent = statRent.n
    ? 0.6 * statRent.mean + 0.4 * statRent.median
    : mean(rows.map(r => r.rent));
  const baselineRet = statRet.n
    ? 0.6 * statRet.mean + 0.4 * statRet.median
    : mean(rows.map(r => r.ret));

  const fusedRent = wSample * baselineRent + wTrend * (trendRent ?? baselineRent);
  const fusedRet  = wSample * baselineRet  + wTrend * (trendRet  ?? baselineRet);

  const predRent = clamp(Math.round(fusedRent), 0, totalSlots);
  const predRet  = clamp(Math.round(fusedRet),  0, totalSlots - predRent);

  // ---- (6) 信心區間 ----
  const sigmaRent = Math.max(opts.sigmaMin, statRent.std || opts.sigmaMin);
  const sigmaRet  = Math.max(opts.sigmaMin, statRet.std  || opts.sigmaMin);
  const ciRent = [
    clamp(Math.round(predRent - opts.sigmaMultiplier * sigmaRent), 0, totalSlots),
    clamp(Math.round(predRent + opts.sigmaMultiplier * sigmaRent), 0, totalSlots),
  ];
  const ciRet = [
    clamp(Math.round(predRet - opts.sigmaMultiplier * sigmaRet), 0, totalSlots - predRent),
    clamp(Math.round(predRet + opts.sigmaMultiplier * sigmaRet), 0, totalSlots - predRent),
  ];

  // ---- (7) 車種比例 ----
  const recentBikes = rows.slice(-30);
  const genMean  = statRent.n ? mean(timeWindowSamples.map(r => r.gen))  : mean(recentBikes.map(r => r.gen));
  const elecMean = statRent.n ? mean(timeWindowSamples.map(r => r.elec)) : mean(recentBikes.map(r => r.elec));
  const totalBikes = genMean + elecMean || 1;
  const genRatio  = genMean / totalBikes;
  const elecRatio = elecMean / totalBikes;

  const predGen  = Math.round(predRent * genRatio);
  const predElec = Math.max(0, predRent - predGen);

  // ---- (8) 風險與信心 ----
  const risk = assessRisk(predRent, predRet, totalSlots, elecRatio);

  const confidence =
    statRent.n >= 10 ? { level: 'high',   label: '高', sampleCount: statRent.n } :
    statRent.n >= 3  ? { level: 'medium', label: '中', sampleCount: statRent.n } :
                       { level: 'low',    label: '低', sampleCount: statRent.n,
                         reason: '同時段樣本不足，建議加大 days 或 window' };

  // ---- (9) 組裝 ----
  return {
    target: {
      iso:     target.toISOString(),
      local:   formatLocal(target),
      weekday: WEEKDAY_ZH[targetWD],
      hour:    targetHr,
      minute:  target.getMinutes(),
    },
    prediction: {
      availableRentBikes:   predRent,
      availableReturnBikes: predRet,
      generalBikes:         predGen,
      electricBikes:        predElec,
      totalSlots,
      rentCIRange:          ciRent,
      returnCIRange:        ciRet,
    },
    confidence,
    risk,
    diagnostics: {
      sampleCount:      statRent.n,
      rawSampleCount:   timeWindowSamples.length,
      windowMinutes:    WINDOW_MIN,
      movingAvgRent:    +statRent.mean.toFixed(2),
      movingAvgReturn:  +statRet.mean.toFixed(2),
      medianRent:       statRent.median,
      medianReturn:     statRet.median,
      stdevRent:        +statRent.std.toFixed(2),
      stdevReturn:      +statRet.std.toFixed(2),
      trendUsed:        useTrend && trendRent != null,
      trendRent:        trendRent != null ? +trendRent.toFixed(2) : null,
      trendReturn:      trendRet  != null ? +trendRet.toFixed(2)  : null,
      trendSlopeRent:   +trendSlopeRent.toFixed(3),
      trendSlopeReturn: +trendSlopeRet.toFixed(3),
      weightSample:     +wSample.toFixed(2),
      weightTrend:      +wTrend.toFixed(2),
      options: {
        useAdaptiveWindow: opts.useAdaptiveWindow,
        useOutlierFilter:  opts.useOutlierFilter,
        useTimeWeight:     opts.useTimeWeight,
        useTrend:          opts.useTrend,
        halfLifeDays:      opts.halfLifeDays,
      },
    },
  };
}

// ============================================================
// 對外主函式（含快取、摘要）
// ============================================================
// services/predict-service.js（或 src/services/predictService.js）
// 以下只放 predictStation，其他函式沿用你原本的即可

export async function predictStation(stationUID, target, options = {}) {
  const t0 = Date.now();

  // ──────────────────────────────
  // 1. 參數驗證
  // ──────────────────────────────
  if (!stationUID) {
    throw makeError('MISSING_STATION', '缺少 station 參數');
  }
  if (!/^[A-Z0-9]{6,20}$/.test(stationUID)) {
    throw makeError('INVALID_STATION', 'station 格式錯誤（需英數 6~20 字）');
  }
  if (!(target instanceof Date) || isNaN(target.getTime())) {
    throw makeError('INVALID_TIME', '時間格式錯誤，需為 Date 或 YYYY-MM-DD HH:mm:ss');
  }

  // ──────────────────────────────
  // 2. 合併預設值（過濾 undefined / null）
  //    關鍵：{ ...DEFAULTS, ...options } 會讓 options.days = undefined
  //          覆蓋 DEFAULTS.days，必須先清掉這些 key
  // ──────────────────────────────
  const cleanOptions = Object.fromEntries(
    Object.entries(options).filter(([_, v]) => v !== undefined && v !== null)
  );
  const opts = { ...DEFAULTS, ...cleanOptions };

  if (!Number.isFinite(opts.days) || opts.days < 1 || opts.days > 365) {
    throw makeError('INVALID_DAYS', 'days 需介於 1~365');
  }
  if (
    !Number.isFinite(opts.window) ||
    opts.window < opts.minWindow ||
    opts.window > opts.maxWindow
  ) {
    throw makeError(
      'INVALID_WINDOW',
      `window 需介於 ${opts.minWindow}~${opts.maxWindow} 分鐘`
    );
  }

  // ──────────────────────────────
  // 3. 快取查詢
  // ──────────────────────────────
  const key = cacheKey(stationUID, target, opts);
  const cached = cacheGet(key);
  if (cached) {
    return {
      ...cached,
      meta: { ...cached.meta, cached: true },
    };
  }

  // ──────────────────────────────
  // 4. 撈歷史資料
  // ──────────────────────────────
  const rows = await fetchHistory(stationUID, opts.days);
  if (!rows.length) {
    throw makeError(
      'NO_DATA',
      `站點 ${stationUID} 在近 ${opts.days} 天內查無資料`
    );
  }

  // ──────────────────────────────
  // 5. 計算預測
  // ──────────────────────────────
  const result = computePrediction(rows, target, opts);

  // 補上站點資訊與摘要
  result.station = { uid: stationUID };
  result.summary = buildSummary(stationUID, result);

  const payload = {
    data: result,
    meta: {
      generatedAt: new Date().toISOString(),
      lookbackDays: opts.days,
      historySamples: rows.length,
      elapsedMs: Date.now() - t0,
      cached: false,
    },
  };

  // ──────────────────────────────
  // 6. 寫入快取（TTL 5 分鐘）
  // ──────────────────────────────
  cacheSet(key, payload, opts.cacheTTLms);

  return payload;
}
// ============================================================
// 批次預測
// ============================================================
export async function predictBatch(stationUIDs, target, options = {}) {
  if (!Array.isArray(stationUIDs) || !stationUIDs.length) {
    throw makeError('MISSING_STATIONS', 'stations 參數為空');
  }
  if (stationUIDs.length > 50) {
    throw makeError('TOO_MANY', '一次最多 50 站');
  }

  const settled = await Promise.allSettled(
    stationUIDs.map(uid => predictStation(uid, target, options))
  );

  return {
    success: true,
    data: settled.map((r, i) => ({
      station: stationUIDs[i],
      ...(r.status === 'fulfilled'
        ? { success: true, ...r.value.data }
        : { success: false, error: r.reason?.message || 'unknown', code: r.reason?.code }),
    })),
    meta: {
      generatedAt: new Date().toISOString(),
      count: stationUIDs.length,
    },
  };
}

// ============================================================
// 摘要
// ============================================================
function buildSummary(uid, r) {
  const p = r.prediction;
  const mmdd = r.target.local.slice(5, 10).replace('-', '/');
  const hhmm = r.target.local.slice(11, 16);
  const risk = r.risk.alerts[0] || '';
  return `${uid} 於 ${mmdd} ${hhmm} 預測可借 ${p.availableRentBikes} 台（${p.rentCIRange[0]}~${p.rentCIRange[1]}）、` +
         `可還 ${p.availableReturnBikes} 個（${p.returnCIRange[0]}~${p.returnCIRange[1]}）。${risk}`;
}

// ============================================================
// 錯誤
// ============================================================
function makeError(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}

// ============================================================
// 時區／格式
// ============================================================
function formatLocal(d) {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ` +
         `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

// ============================================================
// 匯出（預設與工具）
// ============================================================
export default {
  predictStation,
  predictBatch,
  computePrediction,
  fetchHistory,
  DEFAULTS,
};

export { DEFAULTS, removeOutliers, weightedMean, adaptiveWindow };