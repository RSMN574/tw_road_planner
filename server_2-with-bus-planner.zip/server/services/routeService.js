// services/routeService.js
import { query, queryOne } from '../db.js';

// 城市 → 路線表（白名單，表名只能是常數）
const ROUTE_TABLE = {
  Taichung:  'Bus.bus_route',
  Taipei:    'Bus.Bus_Taipei_Route',
  Kaohsiung: 'Bus.Bus_Kaohsiung_Route',
};

// 城市 → 站牌表（對照原本 Bus_${city}_Stop）
export const STOP_TABLE = {
  Taichung:  'Bus.Bus_Taichung_Stop',
  Taipei:    'Bus.Bus_Taipei_Stop',
  Kaohsiung: 'Bus.Bus_Kaohsiung_Stop',
};

// ── 對照 getBusRouteWithId ──
export async function getRouteById(city, routeId) {
  const c = (city || '').trim();

  if (c === 'all') {
    return await queryOne(
      'SELECT * FROM Bus.bus_route WHERE RouteID = ? LIMIT 1',
      [routeId]
    );
  }
  if (c === 'InterCity') {
    return await queryOne(
      'SELECT * FROM Bus.Bus_InterCity_Route WHERE RouteID = ? LIMIT 1',
      [routeId]
    );
  }
  return await queryOne(
    'SELECT * FROM Bus.bus_route WHERE City = ? AND RouteID = ? LIMIT 1',
    [c, routeId]
  );
}

export async function getRoutesByCity(city) {
  const c = (city || '').trim();

  if (!c || c === 'all') {
    return await query('SELECT * FROM Bus.bus_route');
  }
  if (c === 'InterCity') {
    return await query('SELECT * FROM Bus.Bus_InterCity_Route');
  }
  // 其他（含 Taichung / Taipei / Kaohsiung）一律用 City 過濾
  return await query('SELECT * FROM Bus.bus_route WHERE City = ?', [c]);
}
// ── 對照 getBusStopOfRoute ──
export async function getStopsOfRoute(city, routeId) {
  const c = (city || '').trim();

  if (c === 'InterCity') {
    return await query(
      'SELECT * FROM Bus.Bus_InterCity_Route_Stop WHERE RouteID = ?',
      [routeId]
    );
  }
  return await query(
    'SELECT * FROM Bus.stopOfRoute WHERE City = ? AND RouteID = ?',
    [c, routeId]
  );
}

// ── 對照 getRouteStops（參數化） ──
export async function getRouteStops(routeName, direction) {
  return await query(
    `SELECT * FROM Bus.Bus_Taichung_Route_Stop
     WHERE JSON_UNQUOTE(JSON_EXTRACT(RouteName, '$.Zh_tw')) = ?
       AND Direction = ?
     LIMIT 1`,
    [routeName, direction]
  );
}