'use strict';
const { query } = require('../db');

// 與 Dart 的 calculateApproxDistance 等效（Haversine，回傳公里）
function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

// ── 對照 fetchTrainStationFacility ──
async function getStationFacility(stationID) {
  const facility = await query(
    'SELECT * FROM Train.Station_StationFacility WHERE StationID = ?',
    [stationID]
  );
  const station = await query(
    'SELECT * FROM Train.Train_Station WHERE StationID = ?',
    [stationID]
  );
  return [...facility, ...station];
}

// ── 對照 getNearTrainStation ──
async function getNearStations(lat, lon, maxKm = 30, count = 5) {
  const rows = await query(
    'SELECT StationName, StationID, StationPosition, LocationCity, LocationTown FROM Train.Train_Station'
  );

  const withDist = rows
    .map((s) => {
      let pos = s.StationPosition;
      if (typeof pos === 'string') {
        try { pos = JSON.parse(pos); } catch (_) { return null; }
      }
      if (!pos || pos.PositionLat == null || pos.PositionLon == null) return null;
      const distance = haversineKm(lat, lon, pos.PositionLat, pos.PositionLon);
      return { ...s, distance };
    })
    .filter((s) => s && s.distance <= maxKm)
    .sort((a, b) => a.distance - b.distance)
    .slice(0, count);

  return withDist;
}

// ── 對照 getGeneralTrainTimetable（原字串拼接 → 參數化） ──
async function getGeneralTrainTimetable(originName, destinationName) {
  return await query(
    `SELECT t.*,
            s1.StopSequence AS s1_StopSequence,
            s2.StopSequence AS s2_StopSequence
     FROM Train.GeneralTrainTimetable t,
       JSON_TABLE(t.StopTimes, '$[*]' COLUMNS (
         StopSequence INT PATH '$.StopSequence',
         StationID VARCHAR(20) PATH '$.StationID',
         StationNameZh VARCHAR(50) PATH '$.StationName.Zh_tw'
       )) AS s1,
       JSON_TABLE(t.StopTimes, '$[*]' COLUMNS (
         StopSequence INT PATH '$.StopSequence',
         StationID VARCHAR(20) PATH '$.StationID',
         StationNameZh VARCHAR(50) PATH '$.StationName.Zh_tw'
       )) AS s2
     WHERE s1.StationNameZh = ?
       AND s2.StationNameZh = ?
       AND s1.StopSequence < s2.StopSequence
       AND JSON_EXTRACT(t.ServiceDay, '$.Monday') = 1`,
    [originName, destinationName]
  );
}

module.exports = { getStationFacility, getNearStations, getGeneralTrainTimetable };