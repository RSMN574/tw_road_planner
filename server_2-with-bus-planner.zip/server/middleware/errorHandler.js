import { HttpError } from '../utils/httpError.js';
import { logger } from '../utils/logger.js';

export function notFound(req, res) {
  res.status(404).json({ error: 'Not found' });
}

// 維持既有格式：{ error: string }
export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  if (err instanceof HttpError) {
    return res.status(err.status).json({ error: err.message });
  }
  logger.error(`${req.method} ${req.originalUrl}`, err);
  res.status(500).json({ error: 'Internal server error' });
}