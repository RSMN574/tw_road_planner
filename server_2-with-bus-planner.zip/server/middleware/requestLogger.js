import { logger } from '../utils/logger.js';

// 只記錄路徑，不記錄 query 與標頭，避免洩漏金鑰
export function requestLogger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    logger.info(`${req.method} ${req.path} ${res.statusCode} ${Date.now() - start}ms`);
  });
  next();
}