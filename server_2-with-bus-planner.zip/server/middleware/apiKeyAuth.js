import crypto from 'crypto';
import { config } from '../config/env.js';
import { HttpError } from '../utils/httpError.js';

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(a).digest();
  const hb = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(ha, hb);
}

export function apiKeyAuth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return next(new HttpError(401, '缺少授權資訊'));
  }
  if (!config.apiKey) return next(new HttpError(503, '伺服器未設定 API Key'));
  if (!safeEqual(header.split(' ')[1] ?? '', config.apiKey)) {
    return next(new HttpError(403, '無效的 API Key'));
  }
  if (!req.headers['x-timestamp']) {
    return next(new HttpError(400, '缺少時間戳記'));
  }
  next();
}