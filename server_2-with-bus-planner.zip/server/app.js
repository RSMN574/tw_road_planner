// /home/rsmn/server/app.js
import express from 'express';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import routes from './routes/index.js';
import cors from 'cors';
import { errorHandler, notFound } from './middleware/errorHandler.js';
import { requestLogger } from './middleware/requestLogger.js';
import { busPlanner } from './bus-planner/server/express-mount.mjs';   // ← 新增：台灣通路線規劃（bus-planner）

export function createApp() {
  const app = express();

  // 1. 基本安全
  app.disable('x-powered-by');
// 啟用信任代理（如果是單層 Nginx 轉發，傳入 1 或 true）
app.set('trust proxy', 1);
 // 新增：bus-planner 網頁＋API 掛在 /bus-planner/（放在 CORS、限流、body parser 之前；它有自己的限流與錯誤處理，原本的路由不受影響）
 app.use('/bus-planner', busPlanner());
 // 2. CORS —— 必须在 routes 之前，最好最前
 app.use(cors({
  origin: ['http://127.0.0.1:8080', 'http://localhost:8080'],
  methods: ['GET', 'POST', 'PUT'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-timestamp'],  // ← 加这个
  credentials: true,
  maxAge: 86400,
}));
// 接著才註冊 rate limiter
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
});
app.use(limiter);
  // 2. 全域中間件（必須在 routes 之前）
  app.use(compression());
  app.use(express.json());               // 解析 JSON body（POST /tokens 等需要）
  app.use(express.urlencoded({ extended: true }));
  app.use(rateLimit({ windowMs: 60_000, max: 120 }));

  // 3. 日誌（也要在 routes 之前）
  app.use(requestLogger);

  // 4. 路由（只掛一次！）
  app.use(routes);

  // 5. 404 與錯誤處理（必須最後）
  app.use(notFound);
  app.use(errorHandler);

  return app;
}