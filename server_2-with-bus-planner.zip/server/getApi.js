import 'dotenv/config';
import fetch from 'node-fetch';
import fs from 'fs';
import mysql from 'mysql';

let Busdata = '';
const url = 'https://tdx.transportdata.tw/api/basic/v2/Bus/StopOfRoute/City/Taichung?%24&%24format=JSON'; // 替换为实际的 URL
const tableName = 'Bus_Taichung';

async function fetchJsonAndConvertToSQL(url, tableName) {
    try {
        const apiUrl = url;
        const accessToken = await fs.promises.readFile('token.txt', 'utf8');

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const jsonData = await response.json();

        // 创建表的SQL语句
        const createTableSQL = createTableSQLFromJson(jsonData[0], tableName);
        Busdata += createTableSQL;

        // 生成单条插入的 SQL 语句
        if (Array.isArray(jsonData)) {
            jsonData.forEach(json => {
                const sqlQuery = jsonToSQL(json, tableName);
                Busdata += sqlQuery + '\n';
            });
        } else {
            const sqlQuery = jsonToSQL(jsonData, tableName); // 处理单条记录
            Busdata += sqlQuery + '\n';
        }

        await fileWrite();
        await sqlwrite();
        return jsonData;
    } catch (error) {
        console.error('Error fetching or processing data:', error);
    }
}

function createTableSQLFromJson(json, tableName) {
    let columns = ["UID INT PRIMARY KEY AUTO_INCREMENT"];

    for (const key in json) {
        if (json.hasOwnProperty(key)) {
            let columnType = 'TEXT'; // 默认类型

            if (typeof json[key] === 'number') {
                columnType = Number.isInteger(json[key]) ? 'INTEGER' : 'REAL';
            } else if (typeof json[key] === 'boolean') {
                columnType = 'BOOLEAN';
            } else if (Array.isArray(json[key]) || typeof json[key] === 'object') {
                columnType = 'TEXT'; // 存储为 JSON 字符串
            }

            columns.push(`${key} ${columnType}`);
        }
    }
console.log(columns);
    const columnsString = columns.join(", ");
    return `CREATE TABLE IF NOT EXISTS ${tableName} (${columnsString});\n`;
}

function jsonToSQL(json, tableName) {
    let columns = [];
    let values = [];

    for (const key in json) {
        if (json.hasOwnProperty(key)) {
            columns.push(key);
            values.push(formatValue(json[key]));
        }
    }

    const columnsString = columns.join(", ");
    const valuesString = values.join(", ");
    const alias = 'new_values'; // 別名

    // 使用別名來替代 VALUES()
    const updateString = columns.map(key => `${key} = ${alias}.${key}`).join(", ");
    
    return `INSERT INTO ${tableName} (${columnsString}) 
            VALUES (${valuesString}) AS ${alias} 
            ON DUPLICATE KEY UPDATE ${updateString};`;
}

function formatValue(value) {
    if (value === null || value === undefined) {
        return "NULL";
    } else if (typeof value === 'string') {
        return `'${value.replace(/'/g, "''")}'`;
    } else if (typeof value === 'boolean') {
        return value ? "TRUE" : "FALSE";
    } else if (typeof value === 'number') {
        return value;
    } else if (Array.isArray(value) || typeof value === 'object') {
        return `'${JSON.stringify(value).replace(/'/g, "''")}'`; // 将数组或对象存储为 JSON 字符串
    } else {
        return `'${String(value).replace(/'/g, "''")}'`;
    }
}

async function fileWrite() {
    try {
        await fs.promises.writeFile('output.sql', Busdata);
        console.log('SQL write operation complete.');
    } catch (err) {
        console.error('Error writing SQL file:', err);
    }
}

async function sqlwrite() {
    const connection = mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: 'Bus'
    });

    connection.connect(err => {
        if (err) {
            console.error('MySQL connection failed: ', err.stack);
            return;
        }
        console.log('Connected to MySQL as ID ', connection.threadId);
    });
console.log(Busdata);
    // connection.query(Busdata, (err, result) => {
    //     if (err) {
    //         console.error('SQL query failed: ', err.stack);
    //     } else {
    //         console.log('SQL query success:', result);
    //     }
    //     connection.end(err => {
    //         if (err) {
    //             console.error('Error closing MySQL connection:', err);
    //         } else {
    //             console.log('MySQL connection closed.');
    //         }
    //     });
    // });
}

// 调用函数以获取数据并生成 SQL 语句
fetchJsonAndConvertToSQL(url, tableName);
