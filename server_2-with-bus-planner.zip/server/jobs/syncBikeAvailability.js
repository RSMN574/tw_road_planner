/**
 * YouBike Availability History Collector
 *
 * 功能：
 * 1. 透過 TDX API 蒐集全台 YouBike 即時車輛資料
 * 2. 支援 $top / $skip 完整分頁
 * 3. 寫入 bike_availability_history
 * 4. 每日依指定時段自動排程
 * 5. 使用 Node.js setTimeout，不使用 crontab
 *
 * 執行：
 *   node jobs/syncBikeAvailability.js
 *   node jobs/syncBikeAvailability.js --once
 *   node jobs/syncBikeAvailability.js --now
 */
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { getUpdatePool } from '../config/db.js';


import { setTimeout as sleep } from 'node:timers/promises';

// ============================================================
// 基本設定
// ============================================================

const API_BASE =
    'https://tdx.transportdata.tw/api/basic/v2/Bike/Availability/City';

const TIME_ZONE = 'Asia/Taipei';

const PAGE_SIZE = 1000;

const INSERT_BATCH_SIZE = 300;

const RETRY_LIMIT = 3;

const REQUEST_TIMEOUT = 30000;

// ============================================================
// TDX 城市清單
// ============================================================

const CITIES = [
    'Taipei',
    'NewTaipei',
    'Taoyuan',
    'Taichung',
    'Tainan',
    'Kaohsiung',
    'Keelung',
    'Hsinchu',
    'HsinchuCounty',
    'MiaoliCounty',
    'ChanghuaCounty',
    'NantouCounty',
    'YunlinCounty',
    'Chiayi',
    'ChiayiCounty',
    'PingtungCounty',
    'YilanCounty',
    'HualienCounty',
    'TaitungCounty',
    'PenghuCounty',
    'KinmenCounty',
    'LienchiangCounty',
];

// ============================================================
// 每日排程（台灣時間）
// ============================================================

const SCHEDULE = [
    '06:00',
    '06:15',
    '06:30',
    '06:45',

    '07:00',
    '07:15',
    '07:30',
    '07:45',

    '08:00',
    '09:00',
    '10:00',
    '11:00',

    '12:00',
    '12:30',
    '13:00',

    '14:00',
    '15:00',

    '16:00',
    '16:15',
    '16:30',
    '16:45',

    '17:00',
    '17:15',
];

// ============================================================
// Logger
// ============================================================

function log(level, message, data = null) {
    const timestamp = new Date().toLocaleString('zh-TW', {
        timeZone: TIME_ZONE,
        hour12: false,
    });

    const prefix = `[${timestamp}] [${level}]`;

    if (data !== null) {
        console.log(prefix, message, data);
    } else {
        console.log(prefix, message);
    }
}

// ============================================================
// 日期處理
// ============================================================

function getTaipeiParts(date = new Date()) {
    const parts = new Intl.DateTimeFormat('en-GB', {
        timeZone: TIME_ZONE,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hourCycle: 'h23',
    }).formatToParts(date);

    const result = {};

    for (const part of parts) {
        if (part.type !== 'literal') {
            result[part.type] = Number(part.value);
        }
    }

    return result;
}

/**
 * 取得台灣時間格式：
 * YYYY-MM-DD HH:mm:ss
 *
 * MySQL DATETIME 不儲存時區資訊。
 * 這裡統一使用台灣本地時間。
 */
function toTaipeiDateTime(date = new Date()) {
    const p = getTaipeiParts(date);

    return [
        `${p.year}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`,
        `${String(p.hour).padStart(2, '0')}:${String(p.minute).padStart(2, '0')}:${String(p.second).padStart(2, '0')}`,
    ].join(' ');
}

/**
 * 將 TDX 時間轉換成 MySQL DATETIME。
 *
 * 保留 TDX 傳回的當地時間，不經過 JavaScript Date
 * 的時區轉換，避免時間偏移。
 */
function normalizeTdxDateTime(value) {
    if (!value || typeof value !== 'string') {
        return null;
    }

    const match = value.match(
        /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})/
    );

    if (!match) {
        return null;
    }

    return `${match[1]} ${match[2]}`;
}

// ============================================================
// Token 處理
// ============================================================



// token.txt 路徑
const TOKEN_FILE = '/home/rsmn/server/token.txt';

async function fetchToken() {
    try {
        const result = await readFile(TOKEN_FILE, 'utf8');

        const token = result.trim();

        if (!token) {
            throw new Error('token.txt 是空的');
        }

        // 避免檔案內已經包含 Bearer 前綴
        return token.replace(/^Bearer\s+/i, '');

    } catch (error) {
        throw new Error(
            `讀取 TDX Token 失敗：${error.message}`
        );
    }
}
// ============================================================
// API Request
// ============================================================

async function requestPage(url, token) {
    let lastError;

    for (let attempt = 1; attempt <= RETRY_LIMIT; attempt++) {
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    Accept: 'application/json',
                },
                signal: AbortSignal.timeout(REQUEST_TIMEOUT),
            });

            if (!response.ok) {
                const body = await response.text();

                const error = new Error(
                    `HTTP ${response.status}: ${body.slice(0, 300)}`
                );

                error.status = response.status;

                // 只有限流或伺服器錯誤才重試
                if (
                    response.status !== 429 &&
                    response.status < 500
                ) {
                    throw error;
                }

                throw error;
            }

            const data = await response.json();

            if (!Array.isArray(data)) {
                throw new Error('TDX API 回傳格式不是 Array');
            }

            return data;
        } catch (error) {
            lastError = error;

            // 非 429 的 4xx 不重試
            if (
                error.status &&
                error.status >= 400 &&
                error.status < 500 &&
                error.status !== 429
            ) {
                throw error;
            }

            log(
                'WARN',
                `API 請求失敗，第 ${attempt}/${RETRY_LIMIT} 次`,
                error.message
            );

            if (attempt < RETRY_LIMIT) {
                await sleep(1000 * attempt);
            }
        }
    }

    throw lastError;
}

// ============================================================
// 完整分頁取得 Availability
// ============================================================

async function fetchCityAvailability(city, token) {
    const allRecords = [];

    let skip = 0;

    while (true) {
        const params = new URLSearchParams({
            '$top': String(PAGE_SIZE),
            '$skip': String(skip),
            '$format': 'JSON',
        });

        const url =
            `${API_BASE}/${encodeURIComponent(city)}?${params}`;

        log(
            'INFO',
            `${city} 取得資料：skip=${skip}, top=${PAGE_SIZE}`
        );

        const records = await requestPage(url, token);

        allRecords.push(...records);

        log(
            'INFO',
            `${city} 本頁取得 ${records.length} 筆`
        );

        if (records.length < PAGE_SIZE) {
            break;
        }

        skip += PAGE_SIZE;
    }

    return allRecords;
}

// ============================================================
// 資料轉換
// ============================================================

function toNumberOrNull(value) {
    if (value === null || value === undefined || value === '') {
        return null;
    }

    const number = Number(value);

    return Number.isFinite(number) ? number : null;
}

/**
 * AuthorityID 使用 StationUID 前三碼。
 *
 * 例如：
 * TXG500601001 -> TXG
 *
 * 若 UID 不符合格式，使用 API 城市名稱作為 fallback。
 */
function getAuthorityID(record, city) {
    const stationUID = String(record.StationUID ?? '');

    if (/^[A-Za-z]{3}/.test(stationUID)) {
        return stationUID.slice(0, 3).toUpperCase();
    }

    return city.slice(0, 10).toUpperCase();
}

function convertRecord(record, city, snapshotAt) {
    if (!record?.StationUID) {
        return null;
    }

    const stationUID = String(record.StationUID);

    return [
        stationUID,
        getAuthorityID(record, city),
        toNumberOrNull(record.ServiceStatus),
        toNumberOrNull(record.AvailableRentBikes),
        toNumberOrNull(record.AvailableReturnBikes),
        snapshotAt,
        normalizeTdxDateTime(record.SrcUpdateTime),
        JSON.stringify(record),
    ];
}

// ============================================================
// MySQL 寫入
// ============================================================

async function insertHistory(rows) {
    if (rows.length === 0) {
        return 0;
    }

const pool = getUpdatePool('Bike');

    const sql = `
        INSERT INTO Bike.bike_availability_history (
            station_uid,
            city,
            service_status,
            available_rent_bikes,
            available_return_bikes,
            snapshot_at,
            source_update_time,
            raw_data
        )
        VALUES ?
        ON DUPLICATE KEY UPDATE
            service_status = VALUES(service_status),
            available_rent_bikes = VALUES(available_rent_bikes),
            available_return_bikes = VALUES(available_return_bikes),
            source_update_time = VALUES(source_update_time),
            raw_data = VALUES(raw_data)
    `;

    let inserted = 0;

    for (
        let i = 0;
        i < rows.length;
        i += INSERT_BATCH_SIZE
    ) {
        const batch = rows.slice(
            i,
            i + INSERT_BATCH_SIZE
        );

        await pool.query(sql, [batch]);

        inserted += batch.length;

        log(
            'INFO',
            `MySQL 寫入 ${batch.length} 筆，累計 ${inserted}/${rows.length}`
        );
    }

    return inserted;
}
// ============================================================
// 單一城市同步
// ============================================================

async function syncCity(city, token, snapshotAt) {
    log('INFO', `開始蒐集 ${city}`);

    const records = await fetchCityAvailability(city, token);

    if (records.length === 0) {
        log('WARN', `${city} 沒有取得任何 Availability 資料`);
        return 0;
    }

    const rows = records
        .map(record => convertRecord(record, city, snapshotAt))
        .filter(Boolean);

    const written = await insertHistory(rows);

    log(
        'INFO',
        `${city} 完成：API ${records.length} 筆，寫入 ${written} 筆`
    );

    return written;
}

// ============================================================
// 全台同步
// ============================================================

async function main() {
    const startTime = Date.now();

    // 全台共用同一個蒐集時間
    const snapshotAt = toTaipeiDateTime();

    log('INFO', '========================================');
    log('INFO', '開始 YouBike Availability 全台蒐集');
    log('INFO', `Snapshot: ${snapshotAt}`);
    log('INFO', `城市數量: ${CITIES.length}`);
    log('INFO', '========================================');

    const token = await fetchToken();

    let successCities = 0;
    let failedCities = 0;
    let totalRows = 0;

    for (const city of CITIES) {
        try {
            const count = await syncCity(
                city,
                token,
                snapshotAt
            );

            totalRows += count;
            successCities++;
        } catch (error) {
            failedCities++;

            log(
                'ERROR',
                `${city} 蒐集失敗`,
                error.message
            );
        }
    }

    const duration = (
        (Date.now() - startTime) / 1000
    ).toFixed(2);

    log('INFO', '========================================');
    log('INFO', 'YouBike Availability 蒐集完成');
    log('INFO', `Snapshot: ${snapshotAt}`);
    log('INFO', `成功城市: ${successCities}`);
    log('INFO', `失敗城市: ${failedCities}`);
    log('INFO', `寫入筆數: ${totalRows}`);
    log('INFO', `執行時間: ${duration} 秒`);
    log('INFO', '========================================');

    if (failedCities > 0) {
        log('WARN', '部分城市蒐集失敗，請檢查 API 與城市支援狀況');
    }

    return {
        successCities,
        failedCities,
        totalRows,
        snapshotAt,
    };
}

// ============================================================
// 排程器
// ============================================================

/**
 * 取得下一個排程時間。
 *
 * 台灣時間固定 UTC+8，沒有日光節約時間。
 * 僅尋找目前時間之後的排程，不補跑已錯過的時段。
 */
function getNextRun() {
    const now = new Date();
    const p = getTaipeiParts(now);

    const currentMs =
        p.hour * 60 * 60 * 1000 +
        p.minute * 60 * 1000 +
        p.second * 1000 +
        now.getMilliseconds();

    const nextTime = SCHEDULE
        .map(time => {
            const [hour, minute] = time.split(':').map(Number);

            return {
                time,
                hour,
                minute,
                ms: hour * 60 * 60 * 1000 +
                    minute * 60 * 1000,
            };
        })
        .find(item => item.ms > currentMs);

    let target;

    if (nextTime) {
        // UTC+8：台灣時間轉 UTC
        target = new Date(
            Date.UTC(
                p.year,
                p.month - 1,
                p.day,
                nextTime.hour - 8,
                nextTime.minute
            )
        );
    } else {
        // 今天已無排程，下一次為隔日 06:00
        target = new Date(
            Date.UTC(
                p.year,
                p.month - 1,
                p.day + 1,
                6 - 8,
                0
            )
        );
    }

    return target;
}

// ============================================================
// 排程執行
// ============================================================

let timer = null;
let isRunning = false;

function scheduleNext() {
    if (timer) {
        clearTimeout(timer);
        timer = null;
    }

    const nextRun = getNextRun();

    const delay = Math.max(
        0,
        nextRun.getTime() - Date.now()
    );

    log(
        'INFO',
        `下一次蒐集時間：${nextRun.toLocaleString('zh-TW', {
            timeZone: TIME_ZONE,
            hour12: false,
        })}`
    );

    timer = setTimeout(async () => {
        if (isRunning) {
            log('WARN', '上一輪尚未結束，略過本次排程');
            scheduleNext();
            return;
        }

        isRunning = true;

        try {
            await main();
        } catch (error) {
            log('ERROR', '全台蒐集發生錯誤', error.stack ?? error.message);
        } finally {
            isRunning = false;
            scheduleNext();
        }
    }, delay);
}

// ============================================================
// 啟動入口
// ============================================================

async function start() {
    const args = process.argv.slice(2);

    // 只執行一次，執行完畢結束程序
    if (args.includes('--once')) {
        await main();
        return;
    }

    // 立即執行一次，完成後繼續每日排程
    if (args.includes('--now')) {
        try {
            await main();
        } catch (error) {
            log('ERROR', '立即蒐集失敗', error.stack ?? error.message);
        }
    }

    log('INFO', 'YouBike Availability Collector 已啟動');
    log('INFO', `時區：${TIME_ZONE}`);
    log('INFO', `每日排程：${SCHEDULE.join(', ')}`);

    scheduleNext();
}

// ============================================================
// Process Events
// ============================================================

process.on('SIGINT', () => {
    log('INFO', '收到 SIGINT，停止排程');

    if (timer) {
        clearTimeout(timer);
    }

    process.exit(0);
});

process.on('SIGTERM', () => {
    log('INFO', '收到 SIGTERM，停止排程');

    if (timer) {
        clearTimeout(timer);
    }

    process.exit(0);
});

start().catch(error => {
    log('ERROR', 'Collector 啟動失敗', error.stack ?? error.message);
    process.exit(1);
});