// routes/predict.js
import { Router } from 'express';
import { predictStation, predictBatch } from '../services/predictService.js';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const station = String(req.query.station || '').trim();
    const target  = parseTime(req.query.time);
    const result  = await predictStation(station, target, parseOptions(req.query));

    if (req.query.format === 'compact') {
      return res.json({ success: true, data: compact(result.data), meta: result.meta });
    }
    res.json({ success: true, ...result });
  } catch (e) {
    sendError(res, e);
  }
});

router.get('/batch', async (req, res) => {
  try {
    const stations = String(req.query.stations || '')
      .split(',').map(s => s.trim()).filter(Boolean);
    const target = parseTime(req.query.time);
    const result = await predictBatch(stations, target, parseOptions(req.query));
    res.json(result);
  } catch (e) {
    sendError(res, e);
  }
});

function parseTime(s) {
  if (!s) { const e = new Error('缺少 time 參數'); e.code = 'MISSING_TIME'; throw e; }
  const str = String(s).includes('T') ? String(s) : String(s).replace(' ', 'T');
  const d = new Date(str);
  if (isNaN(d.getTime())) { const e = new Error('時間格式錯誤'); e.code = 'INVALID_TIME'; throw e; }
  return d;
}

function parseOptions(q) {
  return {
    days:              q.days   != null ? Number(q.days)   : undefined,
    window:            q.window != null ? Number(q.window) : undefined,
    useAdaptiveWindow: q.adaptive === '1' || q.adaptive === 'true',
  };
}

function compact(d) {
  return {
    station:     d.station.uid,
    targetTime:  d.target.local,
    rent:        d.prediction.availableRentBikes,
    ret:         d.prediction.availableReturnBikes,
    rentRange:   d.prediction.rentCIRange,
    returnRange: d.prediction.returnCIRange,
    confidence:  d.confidence.label,
    risk:        d.risk.level,
    alerts:      d.risk.alerts,
    summary:     d.summary,
  };
}

function sendError(res, e) {
  const map = {
    MISSING_STATION: 400, INVALID_STATION: 400,
    MISSING_TIME: 400,    INVALID_TIME: 400,
    INVALID_DAYS: 400,    INVALID_WINDOW: 400,
    MISSING_STATIONS: 400, TOO_MANY: 400,
    NO_DATA: 404,
    ECONNREFUSED: 503, ETIMEDOUT: 503, QUERY_ERROR: 500,
  };
  const code = e.code || 'INTERNAL';
  res.status(map[code] || 500).json({
    success: false,
    error: { code, message: e.message },
  });
}

export default router;