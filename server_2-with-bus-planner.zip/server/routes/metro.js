// src/routes/metro.js
import { Router } from 'express';
import fs from 'fs/promises';
import path from 'path';

const router = Router();

const METRO_DIR = '/home/rsmn/server/data/metro';
const ALLOWED_CITIES = ['taipei', 'kaohsiung', 'taichung'];

// GET /api/metro/cities
router.get('/cities', (req, res) => {
  res.json([
    { id: 'taipei',    name: '台北捷運 (Taipei MRT)' },
    { id: 'kaohsiung', name: '高雄捷運 (Kaohsiung MRT)' },
    { id: 'taichung',  name: '台中捷運 (Taichung MRT)' },
  ]);
});

// GET /api/metro/:city
router.get('/:city', async (req, res, next) => {
  try {
    const { city } = req.params;

    if (!ALLOWED_CITIES.includes(city)) {
      return res.status(404).json({ error: `City not found: ${city}` });
    }

    const filePath = path.join(METRO_DIR, `${city}.json`);
    const content = await fs.readFile(filePath, 'utf8');
    res.type('application/json').send(content);
  } catch (err) {
    if (err.code === 'ENOENT') {
      return res.status(404).json({ error: `File not found for city: ${req.params.city}` });
    }
    next(err); // 交給 errorHandler
  }
});

export default router;