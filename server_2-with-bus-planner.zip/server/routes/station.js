'use strict';
const express = require('express');
const stationService = require('../services/stationService');
const router = express.Router();

// GET /station/search?city=&q=
router.get('/search', async (req, res) => {
  try {
    res.json(await stationService.searchStations(req.query.city, req.query.q || ''));
  } catch (e) {
    console.error('[station/search]', e.message);
    res.status(500).json({ error: 'query failed' });
  }
});

// GET /station/info?city=&stopName=
router.get('/info', async (req, res) => {
  try {
    res.json(await stationService.getStationInfo(req.query.city, req.query.stopName));
  } catch (e) {
    console.error('[station/info]', e.message);
    res.status(500).json({ error: 'query failed' });
  }
});

module.exports = router;