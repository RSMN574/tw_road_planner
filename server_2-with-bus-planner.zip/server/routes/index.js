// src/routes/index.js
import { Router } from 'express';
import predictRouter from './ubike.js';   // ← 新增
import bootstrapRouter from './bootstrap.js';
import authRouter from './auth.js';
import metroRouter from './metro.js';
import metroV2Router from './metroV2.js';
import airportRouter from './airport.js';
import trainRouter from './train.js';
import busRouter from './bus.js';

const router = Router();

// 根路徑與健康檢查


// 認證
router.use('/', authRouter);              // POST /tokens

router.use('/bootstrap', bootstrapRouter);
// 各業務模組
router.use('/api/metro/v2', metroV2Router);   // 必須在 /api/metro 之前（舊的 /:city 會吃掉單層路徑）
router.use('/api/metro', metroRouter);
router.use('/api/airports', airportRouter);
router.use('/api/train', trainRouter);
router.use('/api/bus', busRouter);
router.use('/api/predict', predictRouter);   
export default router;