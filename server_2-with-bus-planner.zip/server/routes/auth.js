// src/routes/auth.js
import { Router } from 'express';
import { apiKeyAuth } from '../middleware/apiKeyAuth.js';
import { readToken } from '../services/tokenService.js';

const router = Router();

const wrap = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

router.post(
  '/tokens',
  apiKeyAuth,
  wrap(async (req, res) => {
    const token = await readToken();
    res.json({ token });
  })
);

export default router;