// src/routes/train.js
import { Router } from 'express';
import queryTrain from '../api/trainRouteFinder.js';
import { parseTrainQuery } from '../utils/validators.js';

const router = Router();

const wrap = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

// GET /api/train
router.get('/', wrap(async (req, res) => {
  res.json(await queryTrain(parseTrainQuery(req.query)));
}));

export default router;