// /home/rsmn/server/routes/metroV2.js
// 掛載位置：routes/index.js 的 /api/metro/v2（必須在 /api/metro 之前）
import { Router } from 'express';
import { metroCatalogService } from '../services/metroCatalogService.js';
import { HttpError } from '../utils/httpError.js';

const UID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const OPERATOR_RE = /^[A-Za-z0-9]{1,10}$/;

const wrap = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

// 與 /bootstrap 相同的快取方式：ETag + max-age。
// 自行比對 If-None-Match（容許弱驗證子 W/ 與多值），不依賴 req.fresh，
// 因為 fetch 類客戶端可能同時帶 Cache-Control: no-cache，會讓 req.fresh 一律判為不新鮮。
function etagMatches(req, etag) {
  const h = req.headers['if-none-match'];
  if (!h) return false;
  return h.split(',').some((v) => {
    const t = v.trim();
    return t === '*' || t.replace(/^W\//, '') === etag;
  });
}

function send(req, res, tag, body) {
  const etag = `"${tag}"`;
  res.set('ETag', etag);
  res.set('Cache-Control', 'public, max-age=300');
  if (etagMatches(req, etag)) return res.status(304).end();
  return res.json(body);
}

export function createMetroV2Router(service = metroCatalogService) {
  const router = Router();

  // GET /api/metro/v2/catalog  系統、路線、車站、轉乘連結
  router.get('/catalog', wrap(async (req, res) => {
    const s = await service.getSnapshot();
    send(req, res, s.version, s.catalog);
  }));

  // GET /api/metro/v2/shapes?operator=TRTC  路線幾何，座標為 [經度, 緯度]
  router.get('/shapes', wrap(async (req, res) => {
    const op = req.query.operator;
    if (op !== undefined && (typeof op !== 'string' || !OPERATOR_RE.test(op))) {
      throw new HttpError(400, 'operator 格式錯誤');
    }
    const s = await service.getSnapshot();
    if (op && !s.operatorCodes.has(op)) throw new HttpError(404, 'Operator not found');
    const shapes = op ? s.shapes.shapes.filter((x) => x.lineUid.startsWith(`${op}-`)) : s.shapes.shapes;
    send(req, res, `${s.version}-${op || 'all'}`, { version: s.version, shapes });
  }));

  // GET /api/metro/v2/stations/:uid/detail  設施與站外接駁；沒資料時對應欄位為 null
  router.get('/stations/:uid/detail', wrap(async (req, res) => {
    const { uid } = req.params;
    if (!UID_RE.test(uid)) throw new HttpError(400, 'uid 格式錯誤');
    const s = await service.getSnapshot();
    if (!s.stationUids.has(uid)) throw new HttpError(404, 'Station not found');
    const d = s.details.get(uid) ?? {};
    send(req, res, `${s.version}-${uid}`, { uid, facilities: d.facilities ?? null, access: d.access ?? null });
  }));

  return router;
}

export default createMetroV2Router();
