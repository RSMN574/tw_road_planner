// src/routes/airport.js
import { Router } from 'express';
import { loadJson } from '../services/staticData.js';
import { HttpError } from '../utils/httpError.js';

const router = Router();

const wrap = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

// GET /api/airports
router.get('/', wrap(async (req, res) => {
  res.json(await loadJson('airports.json'));
}));

// GET /api/airports/:code
router.get('/:code', wrap(async (req, res) => {
  const code = req.params.code.toUpperCase();
  const data = await loadJson('airports.json');
  const airport = Array.isArray(data)
    ? data.find((a) => a.code === code)
    : data[code];
  if (!airport) throw new HttpError(404, 'Airport not found');
  res.json(airport);
}));

export default router;