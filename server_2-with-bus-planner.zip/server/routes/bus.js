// routes/route.js
import { Router } from 'express';
import * as routeService from '../services/routeService.js';

const router = Router();

// GET /route?city=
router.get('/', async (req, res, next) => {
  try {
    res.json(await routeService.getRoutesByCity(req.query.city));
  } catch (e) {
    next(e);
  }
});

// GET /route/stops?routeName=&direction=
router.get('/stops', async (req, res, next) => {
  try {
    res.json(
      await routeService.getRouteStops(
        req.query.routeName,
        req.query.direction
      )
    );
  } catch (e) {
    next(e);
  }
});

// GET /route/:routeId?city=
router.get('/:routeId', async (req, res, next) => {
  try {
    const row = await routeService.getRouteById(
      req.query.city,
      req.params.routeId
    );
    if (!row) return res.status(404).json({ error: 'not found' });
    res.json(row);
  } catch (e) {
    next(e);
  }
});

// GET /route/:routeId/stops?city=
router.get('/:routeId/stops', async (req, res, next) => {
  try {
    res.json(
      await routeService.getStopsOfRoute(
        req.query.city,
        req.params.routeId
      )
    );
  } catch (e) {
    next(e);
  }
});

export default router;