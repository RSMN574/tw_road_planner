import { Router } from 'express';
import { buildBootstrap } from '../services/bootstrapService.js';

const router = Router();

let cache = { data: null, etag: null, at: 0, key: null };
const TTL = 5 * 60 * 1000;

router.get('/', async (req, res, next) => {
  try {
    const city = (req.query.city || 'all').trim();   // ← 預設 all
    const now = Date.now();

    if (!cache.data || cache.key !== city || now - cache.at > TTL) {
      const data = await buildBootstrap(city);
      cache = {
        data,
        key: city,
        etag: `"${Buffer.from(data.version + city).toString('base64')}"`,
        at: now,
      };
    }

    if (req.headers['if-none-match'] === cache.etag) {
      return res.status(304).end();
    }

    res.set('ETag', cache.etag);
    res.set('Cache-Control', 'public, max-age=300');
    res.json(cache.data);
  } catch (e) {
    next(e);
  }
});

export default router;