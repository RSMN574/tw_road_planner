#!/bin/bash
# 載入環境變數 (確保 nvm 等設定生效)
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
export PATH="$NVM_DIR/versions/node/v22.17.0/bin:$PATH"

# 切換目錄
cd /home/rsmn/server

# 執行腳本並輸出日誌
node getToken.js >> /home/rsmn/server/cron.log 2>&1