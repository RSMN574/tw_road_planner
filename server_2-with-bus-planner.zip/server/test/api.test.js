import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../app.js';
import { parseTrainQuery } from '../utils/validators.js';

let server;
let base;

before(async () => {
  process.env.API_KEY = 'test-key';
  const { config } = await import('../config/env.js');
  config.apiKey = 'test-key';
  server = createApp().listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

test('GET /server-time returns ISO time', async () => {
  const body = await (await fetch(`${base}/server-time`)).json();
  assert.ok(!Number.isNaN(Date.parse(body.serverTime)));
});

test('GET /api/airports/:code is case-insensitive and 404s unknown', async () => {
  assert.equal((await fetch(`${base}/api/airports/tpe`)).status, 200);
  const res = await fetch(`${base}/api/airports/ZZZZ`);
  assert.equal(res.status, 404);
  assert.deepEqual(await res.json(), { error: 'Airport not found' });
});

test('bike endpoints keep open CORS', async () => {
  const res = await fetch(`${base}/bike/races`);
  assert.equal(res.status, 200);
  assert.equal(res.headers.get('access-control-allow-origin'), '*');
});

test('POST /tokens auth rules', async () => {
  const post = (h) => fetch(`${base}/tokens`, { method: 'POST', headers: h });
  assert.equal((await post({})).status, 401);
  assert.equal((await post({ authorization: 'Bearer wrong', 'x-timestamp': 'x' })).status, 403);
  assert.equal((await post({ authorization: 'Bearer test-key' })).status, 400);
});

test('GET /api/train validates input before touching the database', async () => {
  for (const q of ['', '?from=1000', '?from=1000&to=1001&day=9', "?from=1';--&to=1001"]) {
    const res = await fetch(`${base}/api/train${q}`);
    assert.equal(res.status, 400, q);
    assert.ok((await res.json()).error);
  }
});

test('parseTrainQuery parses types and defaults day', () => {
  assert.deepEqual(parseTrainQuery({ from: '1000', to: '1001', types: '1101,1107' }), {
    start: '1000', end: '1001', day: 1, allowedIds: ['1101', '1107'],
  });
});

test('unknown route returns JSON 404', async () => {
  const res = await fetch(`${base}/nope`);
  assert.equal(res.status, 404);
});