module.exports = {
  apps: [{
    name: 'index',
    script: './index.js',
    // 明確指定 dotenv 檔案的絕對路徑（選填，若 PM2 抓不到時好用）
    // env_file: '.env', 
    env: {
      PORT: 80, // 直接在此指定，或是讓 dotenv 從檔案讀取
      NODE_ENV: 'production'
    }
  }]
};