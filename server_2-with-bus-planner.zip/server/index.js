import 'dotenv/config';          // ← 必須是第一行
import { createApp } from './app.js';
import { config } from './config/env.js';
import { closePool } from './config/db.js';
import { logger } from './utils/logger.js';

const server = createApp().listen(config.port, () => {
  logger.info(`Server running on port ${config.port}`);
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => server.close(async () => { await closePool(); process.exit(0); }));
}