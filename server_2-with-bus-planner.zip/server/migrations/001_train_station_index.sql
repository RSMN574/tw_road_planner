-- 選擇性、只新增索引，不改資料。執行前請先備份。
-- Train_Station 目前只有 UID 主鍵，StationID 為 TEXT，需使用前綴索引。
-- 若索引已存在會報錯，可忽略。
ALTER TABLE Train.Train_Station ADD INDEX idx_train_station_stationid (StationID(10));