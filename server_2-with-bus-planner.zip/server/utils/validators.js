import { HttpError } from './httpError.js';

const ID_RE = /^[A-Za-z0-9]{1,10}$/;
const TYPE_RE = /^[A-Za-z0-9]{1,6}$/;

export function parseTrainQuery({ from, to, day = 1, types } = {}) {
  if (!from || !to) throw new HttpError(400, '缺少必要參數 from 或 to');
  const start = String(from);
  const end = String(to);
  if (!ID_RE.test(start) || !ID_RE.test(end)) throw new HttpError(400, 'from 或 to 格式錯誤');

  const d = Number(day);
  if (!Number.isInteger(d) || d < 0 || d > 6) throw new HttpError(400, 'day 必須為 0 到 6');

  let allowedIds;
  if (types) {
    allowedIds = String(types).split(',').map((s) => s.trim()).filter(Boolean);
    if (allowedIds.length > 50 || !allowedIds.every((t) => TYPE_RE.test(t))) {
      throw new HttpError(400, 'types 格式錯誤');
    }
  }
  return { start, end, day: d, allowedIds };
}