import { refreshToken } from './services/tokenService.js';
import { logger } from './utils/logger.js';

// 由 cron 執行；不輸出 token 與帳密
refreshToken().catch((err) => {
  logger.error('Error fetching access token:', err.message);
  process.exitCode = 1;
});